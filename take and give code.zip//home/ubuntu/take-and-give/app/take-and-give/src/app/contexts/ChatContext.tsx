"use client";

import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { v4 as uuidv4 } from 'uuid';

// Define message type
export type Message = {
  id: string;
  senderId: string;
  content: string;
  timestamp: Date;
  isRead: boolean;
};

// Define conversation type
export type Conversation = {
  id: string;
  itemId: string;
  initiatorId: string;
  recipientId: string;
  lastMessage?: string;
  lastMessageAt?: Date;
  unreadCount: number;
  messages: Message[];
};

// Define the context type
interface ChatContextType {
  conversations: Conversation[];
  currentConversation: Conversation | null;
  isLoading: boolean;
  error: string | null;
  fetchConversations: (userId: string) => Promise<void>;
  fetchMessages: (conversationId: string) => Promise<void>;
  sendMessage: (conversationId: string, senderId: string, content: string) => Promise<void>;
  createConversation: (itemId: string, initiatorId: string, recipientId: string, initialMessage?: string) => Promise<string>;
  selectConversation: (conversationId: string) => void;
}

// Create the context with default values
const ChatContext = createContext<ChatContextType>({
  conversations: [],
  currentConversation: null,
  isLoading: false,
  error: null,
  fetchConversations: async () => {},
  fetchMessages: async () => {},
  sendMessage: async () => {},
  createConversation: async () => '',
  selectConversation: () => {},
});

// Provider component
interface ChatProviderProps {
  children: ReactNode;
}

export const ChatProvider = ({ children }: ChatProviderProps) => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentConversation, setCurrentConversation] = useState<Conversation | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch all conversations for a user
  const fetchConversations = async (userId: string) => {
    setIsLoading(true);
    setError(null);
    
    try {
      // In a real implementation, this would call the API
      // For this demo, we'll simulate a delay and return fake data
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const fakeConversations: Conversation[] = [
        {
          id: 'conv_1',
          itemId: 'item_1',
          initiatorId: userId,
          recipientId: 'user_2',
          lastMessage: 'Is this still available?',
          lastMessageAt: new Date(Date.now() - 3600000), // 1 hour ago
          unreadCount: 0,
          messages: []
        },
        {
          id: 'conv_2',
          itemId: 'item_2',
          initiatorId: 'user_3',
          recipientId: userId,
          lastMessage: 'I would like to pick this up tomorrow.',
          lastMessageAt: new Date(Date.now() - 86400000), // 1 day ago
          unreadCount: 2,
          messages: []
        },
        {
          id: 'conv_3',
          itemId: 'item_3',
          initiatorId: userId,
          recipientId: 'user_4',
          lastMessage: 'Thank you for the item!',
          lastMessageAt: new Date(Date.now() - 259200000), // 3 days ago
          unreadCount: 0,
          messages: []
        }
      ];
      
      setConversations(fakeConversations);
    } catch (err) {
      setError('Failed to fetch conversations. Please try again.');
      console.error('Error fetching conversations:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch messages for a conversation
  const fetchMessages = async (conversationId: string) => {
    setIsLoading(true);
    setError(null);
    
    try {
      // In a real implementation, this would call the API
      // For this demo, we'll simulate a delay and return fake data
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const conversation = conversations.find(c => c.id === conversationId);
      
      if (!conversation) {
        throw new Error('Conversation not found');
      }
      
      // Generate fake messages
      const fakeMessages: Message[] = [
        {
          id: 'msg_1',
          senderId: conversation.initiatorId,
          content: 'Hi, is this item still available?',
          timestamp: new Date(Date.now() - 7200000), // 2 hours ago
          isRead: true
        },
        {
          id: 'msg_2',
          senderId: conversation.recipientId,
          content: 'Yes, it is! When would you like to pick it up?',
          timestamp: new Date(Date.now() - 3600000), // 1 hour ago
          isRead: conversation.recipientId !== currentConversation?.recipientId
        },
        {
          id: 'msg_3',
          senderId: conversation.initiatorId,
          content: 'I can come by tomorrow afternoon if that works for you.',
          timestamp: new Date(Date.now() - 1800000), // 30 minutes ago
          isRead: true
        }
      ];
      
      // Update the conversation with messages
      const updatedConversation = { ...conversation, messages: fakeMessages };
      
      // Update conversations list
      setConversations(prevConversations => 
        prevConversations.map(c => 
          c.id === conversationId ? updatedConversation : c
        )
      );
      
      // Update current conversation if it's the one we're fetching
      if (currentConversation?.id === conversationId) {
        setCurrentConversation(updatedConversation);
      }
      
    } catch (err) {
      setError('Failed to fetch messages. Please try again.');
      console.error('Error fetching messages:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Send a message in a conversation
  const sendMessage = async (conversationId: string, senderId: string, content: string) => {
    setIsLoading(true);
    setError(null);
    
    try {
      // In a real implementation, this would call the API
      // For this demo, we'll simulate a delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Create a new message
      const newMessage: Message = {
        id: `msg_${uuidv4()}`,
        senderId,
        content,
        timestamp: new Date(),
        isRead: false
      };
      
      // Update conversations list
      setConversations(prevConversations => 
        prevConversations.map(c => {
          if (c.id === conversationId) {
            return {
              ...c,
              messages: [...c.messages, newMessage],
              lastMessage: content,
              lastMessageAt: new Date()
            };
          }
          return c;
        })
      );
      
      // Update current conversation if it's the one we're sending to
      if (currentConversation?.id === conversationId) {
        setCurrentConversation(prev => {
          if (!prev) return null;
          return {
            ...prev,
            messages: [...prev.messages, newMessage],
            lastMessage: content,
            lastMessageAt: new Date()
          };
        });
      }
      
    } catch (err) {
      setError('Failed to send message. Please try again.');
      console.error('Error sending message:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Create a new conversation
  const createConversation = async (itemId: string, initiatorId: string, recipientId: string, initialMessage?: string): Promise<string> => {
    setIsLoading(true);
    setError(null);
    
    try {
      // In a real implementation, this would call the API
      // For this demo, we'll simulate a delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Generate a new conversation ID
      const conversationId = `conv_${uuidv4()}`;
      
      // Create a new conversation
      const newConversation: Conversation = {
        id: conversationId,
        itemId,
        initiatorId,
        recipientId,
        unreadCount: 0,
        messages: []
      };
      
      // If initial message is provided, add it
      if (initialMessage) {
        const message: Message = {
          id: `msg_${uuidv4()}`,
          senderId: initiatorId,
          content: initialMessage,
          timestamp: new Date(),
          isRead: false
        };
        
        newConversation.messages = [message];
        newConversation.lastMessage = initialMessage;
        newConversation.lastMessageAt = new Date();
      }
      
      // Add the new conversation to the list
      setConversations(prev => [...prev, newConversation]);
      
      return conversationId;
    } catch (err) {
      setError('Failed to create conversation. Please try again.');
      console.error('Error creating conversation:', err);
      return '';
    } finally {
      setIsLoading(false);
    }
  };

  // Select a conversation to view
  const selectConversation = (conversationId: string) => {
    const conversation = conversations.find(c => c.id === conversationId);
    
    if (conversation) {
      // Mark messages as read
      const updatedConversation = {
        ...conversation,
        unreadCount: 0,
        messages: conversation.messages.map(m => ({
          ...m,
          isRead: true
        }))
      };
      
      setCurrentConversation(updatedConversation);
      
      // Update conversations list
      setConversations(prevConversations => 
        prevConversations.map(c => 
          c.id === conversationId ? updatedConversation : c
        )
      );
    }
  };

  return (
    <ChatContext.Provider
      value={{
        conversations,
        currentConversation,
        isLoading,
        error,
        fetchConversations,
        fetchMessages,
        sendMessage,
        createConversation,
        selectConversation,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

// Custom hook to use the chat context
export const useChat = () => useContext(ChatContext);
