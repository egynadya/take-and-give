"use client";

import React from 'react';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import ItemCard from '../components/ui/ItemCard';

const ProfilePage = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        {/* Profile Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <div className="flex flex-col md:flex-row items-center md:items-start">
            <div className="w-32 h-32 bg-gray-200 rounded-full mb-4 md:mb-0 md:mr-6 flex-shrink-0">
              <div className="h-full w-full flex items-center justify-center text-gray-500">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </div>
            </div>
            
            <div className="text-center md:text-left flex-grow">
              <h1 className="text-2xl font-bold mb-1">Sophie Laurent</h1>
              <p className="text-gray-600 mb-2">Paris, France</p>
              <div className="flex flex-wrap justify-center md:justify-start gap-4 mb-4">
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  <span className="text-sm text-gray-600">Member since January 2025</span>
                </div>
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v13m0-13V6a4 4 0 00-4-4H8.8a4 4 0 00-2.6 1L5 4m7 4v13m0-13h4.8a4 4 0 012.6 1l1.2 1" />
                  </svg>
                  <span className="text-sm text-gray-600">12 items given</span>
                </div>
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                  </svg>
                  <span className="text-sm text-gray-600">8 items received</span>
                </div>
              </div>
            </div>
            
            <div className="mt-4 md:mt-0 flex flex-col space-y-2">
              <Button variant="primary">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                </svg>
                Edit Profile
              </Button>
              <Button variant="outline">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
                Settings
              </Button>
            </div>
          </div>
          
          <div className="mt-6">
            <h2 className="text-lg font-medium mb-2">About</h2>
            <p className="text-gray-700">
              Hello! I'm Sophie, a graphic designer living in Paris. I love minimalist design and try to live a sustainable lifestyle. 
              I'm passionate about reducing waste and giving items a second life instead of throwing them away.
            </p>
          </div>
        </div>
        
        {/* Profile Tabs */}
        <div className="mb-6">
          <div className="border-b border-gray-200">
            <nav className="flex -mb-px">
              <a href="#" className="border-b-2 border-[rgb(var(--primary-color))] text-[rgb(var(--primary-color))] px-4 py-2 font-medium">
                My Items
              </a>
              <a href="#" className="border-b-2 border-transparent text-gray-500 hover:text-gray-700 px-4 py-2 font-medium">
                Favorites
              </a>
              <a href="#" className="border-b-2 border-transparent text-gray-500 hover:text-gray-700 px-4 py-2 font-medium">
                Messages
              </a>
              <a href="#" className="border-b-2 border-transparent text-gray-500 hover:text-gray-700 px-4 py-2 font-medium">
                History
              </a>
            </nav>
          </div>
        </div>
        
        {/* Item Filters */}
        <div className="mb-6 flex flex-wrap gap-2">
          <Button variant="primary">Available</Button>
          <Button variant="outline">Reserved</Button>
          <Button variant="outline">Completed</Button>
        </div>
        
        {/* Items Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
          {[1, 2, 3, 4, 5, 6].map((index) => (
            <ItemCard
              key={index}
              title={index === 1 ? 'Wooden Dining Table' : 
                    index === 2 ? 'Coffee Table' : 
                    index === 3 ? 'Desk Lamp' :
                    index === 4 ? 'Winter Jacket' :
                    index === 5 ? 'Fiction Books' :
                    'Baby Stroller'}
              category={index <= 2 ? 'Furniture' : 
                       index === 3 ? 'Miscellaneous' :
                       index === 4 ? 'Clothes & Fashion' :
                       index === 5 ? 'Books' :
                       'Kids'}
              distance={`${(index * 1.2).toFixed(1)} km away`}
              status={index === 2 ? 'reserved' : 
                     index === 5 ? 'completed' : 
                     'available'}
              onClick={() => console.log(`Clicked on item ${index}`)}
            />
          ))}
        </div>
        
        {/* Load More Button */}
        <div className="text-center">
          <Button variant="outline">Load More</Button>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default ProfilePage;
