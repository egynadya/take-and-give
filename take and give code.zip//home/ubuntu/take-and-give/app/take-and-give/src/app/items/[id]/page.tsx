import React from 'react';
import Header from '../../components/layout/Header';
import Footer from '../../components/layout/Footer';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';

const ItemDetailsPage = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="mb-4">
          <a href="/browse" className="text-[rgb(var(--secondary-color))] hover:underline flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back to Results
          </a>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Item Images */}
          <div>
            <div className="bg-gray-200 rounded-lg overflow-hidden h-80 mb-4">
              <div className="h-full w-full flex items-center justify-center text-gray-500">
                Primary Image
              </div>
            </div>
            <div className="grid grid-cols-4 gap-2">
              {[1, 2, 3, 4].map((index) => (
                <div key={index} className="bg-gray-200 rounded-lg overflow-hidden h-20">
                  <div className="h-full w-full flex items-center justify-center text-gray-500 text-sm">
                    Image {index}
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Item Details */}
          <div>
            <h1 className="text-3xl font-bold mb-2">Wooden Dining Table</h1>
            <div className="text-sm text-gray-500 mb-4">
              <span className="mr-2">Category: Furniture</span>
              <span>Posted: 2 days ago</span>
            </div>
            
            <div className="flex items-center mb-6">
              <div className="bg-gray-100 rounded-full p-2 mr-3">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              </div>
              <div>
                <div className="font-medium">Saint-Michel, Paris</div>
                <div className="text-sm text-gray-500">2.5 km away</div>
              </div>
            </div>
            
            <div className="flex space-x-3 mb-6">
              <Button variant="primary">Contact</Button>
              <Button variant="outline">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                </svg>
                Favorite
              </Button>
            </div>
            
            <div className="mb-6">
              <h2 className="text-xl font-medium mb-2">Description</h2>
              <p className="text-gray-700">
                Beautiful wooden dining table in excellent condition. Solid oak with a natural finish. 
                Dimensions: 150cm x 90cm x 75cm (LxWxH). Can seat 6 people comfortably.
                No scratches or damage. Must pick up from my apartment.
              </p>
            </div>
            
            <div className="mb-6">
              <h2 className="text-xl font-medium mb-2">Donor Information</h2>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gray-200 rounded-full mr-3"></div>
                <div>
                  <div className="font-medium">Sophie L.</div>
                  <div className="text-sm text-gray-500">Member since January 2025</div>
                  <div className="text-sm text-gray-500">12 items given</div>
                </div>
              </div>
            </div>
            
            <div className="mb-6">
              <h2 className="text-xl font-medium mb-2">Transportation Options</h2>
              <div className="space-y-2 text-gray-700">
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                  </svg>
                  <span>Public Transit: Metro Line 4, Saint-Michel station (5 min walk)</span>
                </div>
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                  <span>Driving: 10 minutes from city center, street parking available</span>
                </div>
              </div>
              <div className="mt-2">
                <Button variant="outline" size="sm">View on Map</Button>
              </div>
            </div>
            
            <div className="border-t border-gray-200 pt-4">
              <Button variant="text" size="sm" className="text-red-600">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
                Report Item
              </Button>
            </div>
          </div>
        </div>
        
        {/* Similar Items */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-6">Similar Items</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((index) => (
              <div key={index} className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition">
                <div className="h-48 bg-gray-200 relative">
                  <div className="absolute inset-0 flex items-center justify-center text-gray-500">
                    Item Image
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-medium mb-1">Similar Item {index}</h3>
                  <p className="text-sm text-gray-500 mb-2">Furniture</p>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">3.{index} km away</span>
                    <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">Available</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default ItemDetailsPage;
