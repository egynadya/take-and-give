import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';

type ItemCardProps = {
  title: string;
  category: string;
  distance: string;
  status: 'available' | 'reserved' | 'completed';
  imageUrl?: string;
  onClick?: () => void;
  className?: string;
};

const ItemCard: React.FC<ItemCardProps> = ({
  title,
  category,
  distance,
  status,
  imageUrl,
  onClick,
  className = '',
}) => {
  const { t } = useLanguage();
  
  const statusColors = {
    available: 'bg-green-100 text-green-800',
    reserved: 'bg-yellow-100 text-yellow-800',
    completed: 'bg-gray-100 text-gray-800',
  };

  // Translate status
  const translatedStatus = t(`status.${status}`);

  return (
    <div 
      className={`border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition cursor-pointer ${className}`}
      onClick={onClick}
    >
      <div className="h-48 bg-gray-200 relative">
        {imageUrl ? (
          <img 
            src={imageUrl} 
            alt={title} 
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center text-gray-500">
            {t('item.no_image')}
          </div>
        )}
      </div>
      <div className="p-4">
        <h3 className="font-medium mb-1 truncate">{title}</h3>
        <p className="text-sm text-gray-500 mb-2">{category}</p>
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-600">{distance}</span>
          <span className={`text-xs px-2 py-1 rounded ${statusColors[status]}`}>
            {translatedStatus}
          </span>
        </div>
      </div>
    </div>
  );
};

export default ItemCard;
