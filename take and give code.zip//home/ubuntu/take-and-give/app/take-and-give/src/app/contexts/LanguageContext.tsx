"use client";

import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// Define available languages
export type Language = 'en' | 'fr';

// Define the context type
interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (key: string) => string;
}

// Create the context with default values
const LanguageContext = createContext<LanguageContextType>({
  language: 'en',
  setLanguage: () => {},
  t: (key: string) => key,
});

// English translations
const enTranslations: Record<string, string> = {
  // Navigation
  'nav.home': 'Home',
  'nav.browse': 'Browse Items',
  'nav.add_item': 'Add Item',
  'nav.messages': 'Messages',
  'nav.profile': 'Profile',
  'nav.login': 'Log In',
  'nav.signup': 'Sign Up',
  'nav.logout': 'Log Out',
  
  // Homepage
  'home.hero.title': 'Give and receive items for free, no limitations',
  'home.hero.subtitle': 'Take & Give connects people who want to give away items they no longer need with those who could use them. No restrictions, no virtual credits, just a community of sharing.',
  'home.hero.browse': 'Browse Items',
  'home.hero.get_started': 'Get Started',
  'home.featured.title': 'Featured Items',
  'home.featured.view_all': 'View All Items',
  'home.categories.title': 'Categories',
  'home.how_it_works.title': 'How It Works',
  'home.how_it_works.step1.title': '1. List Your Items',
  'home.how_it_works.step1.description': 'Take a photo, add a description, and share your item with the community.',
  'home.how_it_works.step2.title': '2. Connect',
  'home.how_it_works.step2.description': 'Chat with interested people and arrange a pickup time and location.',
  'home.how_it_works.step3.title': '3. Exchange',
  'home.how_it_works.step3.description': 'Meet up and give your item a new home. No fees, no limits, no hassle.',
  'home.success_stories.title': 'Success Stories',
  
  // Browse page
  'browse.title': 'Browse Items',
  'browse.filters.title': 'Filters',
  'browse.filters.categories': 'Categories',
  'browse.filters.distance': 'Distance',
  'browse.filters.location': 'Location',
  'browse.filters.apply': 'Apply Filters',
  'browse.sort_by': 'Sort by:',
  'browse.sort.distance': 'Distance',
  'browse.sort.newest': 'Newest',
  'browse.sort.oldest': 'Oldest',
  'browse.items_found': '{count} items found',
  'browse.load_more': 'Load More',
  'browse.no_results': 'No items found. Try adjusting your filters.',
  
  // Item details
  'item.back_to_results': 'Back to Results',
  'item.contact': 'Contact',
  'item.favorite': 'Favorite',
  'item.description': 'Description',
  'item.donor_info': 'Donor Information',
  'item.transportation': 'Transportation Options',
  'item.view_on_map': 'View on Map',
  'item.report_item': 'Report Item',
  'item.similar_items': 'Similar Items',
  
  // Add item
  'add_item.title': 'Add New Item',
  'add_item.info.title': 'Item Information',
  'add_item.info.title_en': 'Title (English)',
  'add_item.info.title_fr': 'Title (French)',
  'add_item.info.category': 'Category',
  'add_item.info.condition': 'Condition',
  'add_item.info.description_en': 'Description (English)',
  'add_item.info.description_fr': 'Description (French)',
  'add_item.photos.title': 'Photos',
  'add_item.photos.description': 'Add up to 5 photos of your item. The first photo will be the main image.',
  'add_item.photos.drag_drop': 'Drag and drop photos here',
  'add_item.photos.or': 'or',
  'add_item.photos.browse': 'Browse Files',
  'add_item.location.title': 'Location',
  'add_item.location.use_default': 'Use my default location',
  'add_item.location.select_saved': 'Or select another location',
  'add_item.location.enter_new': 'Or enter a new location',
  'add_item.availability.title': 'Availability',
  'add_item.availability.from': 'Available from',
  'add_item.availability.pickup_times': 'Preferred pickup times',
  'add_item.availability.days': 'Days of week',
  'add_item.buttons.cancel': 'Cancel',
  'add_item.buttons.preview': 'Preview',
  'add_item.buttons.publish': 'Publish',
  
  // Messages
  'messages.title': 'Messages',
  'messages.search': 'Search messages...',
  'messages.no_messages': 'No messages yet.',
  'messages.view_item': 'View Item',
  'messages.type_message': 'Type a message...',
  'messages.mark_reserved': 'Mark as Reserved',
  'messages.mark_completed': 'Mark as Completed',
  
  // Profile
  'profile.edit': 'Edit Profile',
  'profile.settings': 'Settings',
  'profile.about': 'About',
  'profile.member_since': 'Member since {date}',
  'profile.items_given': '{count} items given',
  'profile.items_received': '{count} items received',
  'profile.tabs.my_items': 'My Items',
  'profile.tabs.favorites': 'Favorites',
  'profile.tabs.messages': 'Messages',
  'profile.tabs.history': 'History',
  'profile.filters.available': 'Available',
  'profile.filters.reserved': 'Reserved',
  'profile.filters.completed': 'Completed',
  'profile.load_more': 'Load More',
  
  // Auth
  'auth.login.title': 'Log In',
  'auth.signup.title': 'Sign Up',
  'auth.email': 'Email',
  'auth.password': 'Password',
  'auth.confirm_password': 'Confirm Password',
  'auth.first_name': 'First Name',
  'auth.last_name': 'Last Name',
  'auth.remember_me': 'Remember me',
  'auth.forgot_password': 'Forgot password?',
  'auth.terms': 'I agree to the Terms of Service and Privacy Policy',
  'auth.newsletter': 'I want to receive updates about new features and items in my area',
  'auth.or': 'or',
  'auth.google': 'Continue with Google',
  'auth.no_account': 'Don\'t have an account?',
  'auth.signup_link': 'Sign up',
  'auth.has_account': 'Already have an account?',
  'auth.login_link': 'Log in',
  
  // Footer
  'footer.description': 'A platform for giving away and receiving free items, with no limitations.',
  'footer.quick_links': 'Quick Links',
  'footer.about': 'About',
  'footer.browse': 'Browse Items',
  'footer.faq': 'FAQ',
  'footer.contact': 'Contact Us',
  'footer.legal': 'Legal',
  'footer.terms': 'Terms of Service',
  'footer.privacy': 'Privacy Policy',
  'footer.cookies': 'Cookie Policy',
  'footer.support_us': 'Support Us',
  'footer.support_description': 'Help us keep Take & Give free for everyone.',
  'footer.donate': 'Donate',
  'footer.copyright': '© 2025 Take & Give. All rights reserved.',
  
  // Categories
  'category.furniture': 'Furniture',
  'category.kids': 'Kids',
  'category.clothes': 'Clothes & Fashion',
  'category.books': 'Books',
  'category.misc': 'Miscellaneous',
  
  // Item conditions
  'condition.new': 'New',
  'condition.like_new': 'Like New',
  'condition.good': 'Good',
  'condition.fair': 'Fair',
  
  // Item status
  'status.available': 'Available',
  'status.reserved': 'Reserved',
  'status.completed': 'Completed',
  
  // Days of week
  'day.monday': 'Monday',
  'day.tuesday': 'Tuesday',
  'day.wednesday': 'Wednesday',
  'day.thursday': 'Thursday',
  'day.friday': 'Friday',
  'day.saturday': 'Saturday',
  'day.sunday': 'Sunday',
  
  // Times of day
  'time.morning': 'Morning',
  'time.afternoon': 'Afternoon',
  'time.evening': 'Evening',
};

// French translations
const frTranslations: Record<string, string> = {
  // Navigation
  'nav.home': 'Accueil',
  'nav.browse': 'Parcourir les Articles',
  'nav.add_item': 'Ajouter un Article',
  'nav.messages': 'Messages',
  'nav.profile': 'Profil',
  'nav.login': 'Connexion',
  'nav.signup': 'Inscription',
  'nav.logout': 'Déconnexion',
  
  // Homepage
  'home.hero.title': 'Donnez et recevez des articles gratuitement, sans limitations',
  'home.hero.subtitle': 'Take & Give connecte les personnes qui souhaitent donner des objets dont elles n\'ont plus besoin avec celles qui pourraient les utiliser. Pas de restrictions, pas de crédits virtuels, juste une communauté de partage.',
  'home.hero.browse': 'Parcourir les Articles',
  'home.hero.get_started': 'Commencer',
  'home.featured.title': 'Articles en Vedette',
  'home.featured.view_all': 'Voir Tous les Articles',
  'home.categories.title': 'Catégories',
  'home.how_it_works.title': 'Comment Ça Marche',
  'home.how_it_works.step1.title': '1. Listez Vos Articles',
  'home.how_it_works.step1.description': 'Prenez une photo, ajoutez une description et partagez votre article avec la communauté.',
  'home.how_it_works.step2.title': '2. Connectez-vous',
  'home.how_it_works.step2.description': 'Discutez avec les personnes intéressées et organisez un horaire et un lieu de ramassage.',
  'home.how_it_works.step3.title': '3. Échangez',
  'home.how_it_works.step3.description': 'Rencontrez-vous et donnez à votre article un nouveau foyer. Pas de frais, pas de limites, pas de tracas.',
  'home.success_stories.title': 'Histoires de Réussite',
  
  // Browse page
  'browse.title': 'Parcourir les Articles',
  'browse.filters.title': 'Filtres',
  'browse.filters.categories': 'Catégories',
  'browse.filters.distance': 'Distance',
  'browse.filters.location': 'Emplacement',
  'browse.filters.apply': 'Appliquer les Filtres',
  'browse.sort_by': 'Trier par:',
  'browse.sort.distance': 'Distance',
  'browse.sort.newest': 'Plus récent',
  'browse.sort.oldest': 'Plus ancien',
  'browse.items_found': '{count} articles trouvés',
  'browse.load_more': 'Charger Plus',
  'browse.no_results': 'Aucun article trouvé. Essayez d\'ajuster vos filtres.',
  
  // Item details
  'item.back_to_results': 'Retour aux Résultats',
  'item.contact': 'Contacter',
  'item.favorite': 'Favori',
  'item.description': 'Description',
  'item.donor_info': 'Informations sur le Donateur',
  'item.transportation': 'Options de Transport',
  'item.view_on_map': 'Voir sur la Carte',
  'item.report_item': 'Signaler l\'Article',
  'item.similar_items': 'Articles Similaires',
  
  // Add item
  'add_item.title': 'Ajouter un Nouvel Article',
  'add_item.info.title': 'Informations sur l\'Article',
  'add_item.info.title_en': 'Titre (Anglais)',
  'add_item.info.title_fr': 'Titre (Français)',
  'add_item.info.category': 'Catégorie',
  'add_item.info.condition': 'État',
  'add_item.info.description_en': 'Description (Anglais)',
  'add_item.info.description_fr': 'Description (Français)',
  'add_item.photos.title': 'Photos',
  'add_item.photos.description': 'Ajoutez jusqu\'à 5 photos de votre article. La première photo sera l\'image principale.',
  'add_item.photos.drag_drop': 'Glissez et déposez des photos ici',
  'add_item.photos.or': 'ou',
  'add_item.photos.browse': 'Parcourir les Fichiers',
  'add_item.location.title': 'Emplacement',
  'add_item.location.use_default': 'Utiliser mon emplacement par défaut',
  'add_item.location.select_saved': 'Ou sélectionnez un autre emplacement',
  'add_item.location.enter_new': 'Ou entrez un nouvel emplacement',
  'add_item.availability.title': 'Disponibilité',
  'add_item.availability.from': 'Disponible à partir de',
  'add_item.availability.pickup_times': 'Heures de ramassage préférées',
  'add_item.availability.days': 'Jours de la semaine',
  'add_item.buttons.cancel': 'Annuler',
  'add_item.buttons.preview': 'Aperçu',
  'add_item.buttons.publish': 'Publier',
  
  // Messages
  'messages.title': 'Messages',
  'messages.search': 'Rechercher des messages...',
  'messages.no_messages': 'Pas encore de messages.',
  'messages.view_item': 'Voir l\'Article',
  'messages.type_message': 'Tapez un message...',
  'messages.mark_reserved': 'Marquer comme Réservé',
  'messages.mark_completed': 'Marquer comme Terminé',
  
  // Profile
  'profile.edit': 'Modifier le Profil',
  'profile.settings': 'Paramètres',
  'profile.about': 'À propos',
  'profile.member_since': 'Membre depuis {date}',
  'profile.items_given': '{count} articles donnés',
  'profile.items_received': '{count} articles reçus',
  'profile.tabs.my_items': 'Mes Articles',
  'profile.tabs.favorites': 'Favoris',
  'profile.tabs.messages': 'Messages',
  'profile.tabs.history': 'Historique',
  'profile.filters.available': 'Disponible',
  'profile.filters.reserved': 'Réservé',
  'profile.filters.completed': 'Terminé',
  'profile.load_more': 'Charger Plus',
  
  // Auth
  'auth.login.title': 'Connexion',
  'auth.signup.title': 'Inscription',
  'auth.email': 'Email',
  'auth.password': 'Mot de passe',
  'auth.confirm_password': 'Confirmer le mot de passe',
  'auth.first_name': 'Prénom',
  'auth.last_name': 'Nom',
  'auth.remember_me': 'Se souvenir de moi',
  'auth.forgot_password': 'Mot de passe oublié?',
  'auth.terms': 'J\'accepte les Conditions d\'Utilisation et la Politique de Confidentialité',
  'auth.newsletter': 'Je souhaite recevoir des mises à jour sur les nouvelles fonctionnalités et les articles dans ma région',
  'auth.or': 'ou',
  'auth.google': 'Continuer avec Google',
  'auth.no_account': 'Vous n\'avez pas de compte?',
  'auth.signup_link': 'S\'inscrire',
  'auth.has_account': 'Vous avez déjà un compte?',
  'auth.login_link': 'Se connecter',
  
  // Footer
  'footer.description': 'Une plateforme pour donner et recevoir des articles gratuitement, sans limitations.',
  'footer.quick_links': 'Liens Rapides',
  'footer.about': 'À propos',
  'footer.browse': 'Parcourir les Articles',
  'footer.faq': 'FAQ',
  'footer.contact': 'Contactez-nous',
  'footer.legal': 'Légal',
  'footer.terms': 'Conditions d\'Utilisation',
  'footer.privacy': 'Politique de Confidentialité',
  'footer.cookies': 'Politique de Cookies',
  'footer.support_us': 'Soutenez-nous',
  'footer.support_description': 'Aidez-nous à maintenir Take & Give gratuit pour tous.',
  'footer.donate': 'Faire un Don',
  'footer.copyright': '© 2025 Take & Give. Tous droits réservés.',
  
  // Categories
  'category.furniture': 'Meubles',
  'category.kids': 'Enfants',
  'category.clothes': 'Vêtements & Mode',
  'category.books': 'Livres',
  'category.misc': 'Divers',
  
  // Item conditions
  'condition.new': 'Neuf',
  'condition.like_new': 'Comme Neuf',
  'condition.good': 'Bon',
  'condition.fair': 'Correct',
  
  // Item status
  'status.available': 'Disponible',
  'status.reserved': 'Réservé',
  'status.completed': 'Terminé',
  
  // Days of week
  'day.monday': 'Lundi',
  'day.tuesday': 'Mardi',
  'day.wednesday': 'Mercredi',
  'day.thursday': 'Jeudi',
  'day.friday': 'Vendredi',
  'day.saturday': 'Samedi',
  'day.sunday': 'Dimanche',
  
  // Times of day
  'time.morning': 'Matin',
  'time.afternoon': 'Après-midi',
  'time.evening': 'Soir',
};

// Map of all translations
const translations: Record<Language, Record<string, string>> = {
  en: enTranslations,
  fr: frTranslations,
};

// Provider component
interface LanguageProviderProps {
  children: ReactNode;
}

export const LanguageProvider = ({ children }: LanguageProviderProps) => {
  // Get initial language from localStorage or browser settings
  const getInitialLanguage = (): Language => {
    if (typeof window !== 'undefined') {
      const savedLanguage = localStorage.getItem('language') as Language;
      if (savedLanguage && (savedLanguage === 'en' || savedLanguage === 'fr')) {
        return savedLanguage;
      }
      
      // Check browser language
      const browserLanguage = navigator.language.split('-')[0];
      if (browserLanguage === 'fr') {
        return 'fr';
      }
    }
    
    return 'en'; // Default to English
  };
  
  const [language, setLanguageState] = useState<Language>('en');
  
  // Initialize language after component mounts (to avoid SSR issues)
  useEffect(() => {
    setLanguageState(getInitialLanguage());
  }, []);
  
  // Set language and save to localStorage
  const setLanguage = (newLanguage: Language) => {
    setLanguageState(newLanguage);
    if (typeof window !== 'undefined') {
      localStorage.setItem('language', newLanguage);
    }
  };
  
  // Translation function
  const t = (key: string): string => {
    const translation = translations[language][key];
    return translation || key; // Fallback to key if translation not found
  };
  
  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

// Custom hook to use 
(Content truncated due to size limit. Use line ranges to read in chunks)