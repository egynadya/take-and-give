import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';

type FooterProps = {
  className?: string;
};

const Footer: React.FC<FooterProps> = ({ className }) => {
  const { t } = useLanguage();
  
  return (
    <footer className={`bg-gray-800 text-white py-8 ${className}`}>
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-bold mb-4">Take & Give</h3>
            <p className="text-gray-300 text-sm">
              {t('footer.description')}
            </p>
          </div>
          <div>
            <h4 className="font-medium mb-4">{t('footer.quick_links')}</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li><a href="/about" className="hover:text-white">{t('footer.about')}</a></li>
              <li><a href="/browse" className="hover:text-white">{t('footer.browse')}</a></li>
              <li><a href="/faq" className="hover:text-white">{t('footer.faq')}</a></li>
              <li><a href="/contact" className="hover:text-white">{t('footer.contact')}</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium mb-4">{t('footer.legal')}</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li><a href="/terms" className="hover:text-white">{t('footer.terms')}</a></li>
              <li><a href="/privacy" className="hover:text-white">{t('footer.privacy')}</a></li>
              <li><a href="/cookies" className="hover:text-white">{t('footer.cookies')}</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium mb-4">{t('footer.support_us')}</h4>
            <p className="text-gray-300 text-sm mb-4">
              {t('footer.support_description')}
            </p>
            <a href="/donate" className="px-4 py-2 bg-[rgb(var(--primary-color))] text-white rounded-md hover:bg-opacity-90 transition text-sm inline-block">
              {t('footer.donate')}
            </a>
          </div>
        </div>
        <div className="border-t border-gray-700 mt-8 pt-6 text-center text-sm text-gray-400">
          <p>{t('footer.copyright')}</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
