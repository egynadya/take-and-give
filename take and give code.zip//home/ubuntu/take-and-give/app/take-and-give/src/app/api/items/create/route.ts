import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import { v4 as uuidv4 } from 'uuid';

interface Env {
  DB: D1Database;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Validate required fields
    const requiredFields = ['title_en', 'description_en', 'category_id', 'donor_id', 'location_id', 'condition'];
    for (const field of requiredFields) {
      if (!body[field]) {
        return NextResponse.json(
          { error: `Missing required field: ${field}` },
          { status: 400 }
        );
      }
    }
    
    // Get the database binding from the environment
    const env = request.cf as unknown as Env;
    
    // Generate a unique ID for the item
    const itemId = `item_${uuidv4()}`;
    
    // Insert the item into the database
    await env.DB.prepare(`
      INSERT INTO items (
        id, 
        title_en, 
        title_fr, 
        description_en, 
        description_fr, 
        category_id, 
        donor_id, 
        location_id, 
        condition, 
        status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)
    .bind(
      itemId,
      body.title_en,
      body.title_fr || null,
      body.description_en,
      body.description_fr || null,
      body.category_id,
      body.donor_id,
      body.location_id,
      body.condition,
      body.status || 'available'
    )
    .run();
    
    // Handle item images if provided
    if (body.images && Array.isArray(body.images) && body.images.length > 0) {
      for (let i = 0; i < body.images.length; i++) {
        const image = body.images[i];
        const imageId = `img_${uuidv4()}`;
        
        await env.DB.prepare(`
          INSERT INTO item_images (
            id,
            item_id,
            image_url,
            display_order,
            is_primary
          ) VALUES (?, ?, ?, ?, ?)
        `)
        .bind(
          imageId,
          itemId,
          image.url,
          i,
          i === 0 ? 1 : 0 // First image is primary
        )
        .run();
      }
    }
    
    // Return the created item ID
    return NextResponse.json({
      success: true,
      itemId
    }, { status: 201 });
    
  } catch (error) {
    console.error('Error creating item:', error);
    return NextResponse.json(
      { error: 'Failed to create item' },
      { status: 500 }
    );
  }
}
