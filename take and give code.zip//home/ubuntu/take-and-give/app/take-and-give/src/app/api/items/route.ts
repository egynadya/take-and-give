import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';

interface Env {
  DB: D1Database;
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    
    // Get query parameters
    const category = searchParams.get('category');
    const status = searchParams.get('status') || 'available';
    const distance = searchParams.get('distance');
    const latitude = searchParams.get('latitude');
    const longitude = searchParams.get('longitude');
    const sortBy = searchParams.get('sortBy') || 'newest';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '12');
    const offset = (page - 1) * limit;
    
    // Get the database binding from the environment
    const env = request.cf as unknown as Env;
    
    // Build the query
    let query = `
      SELECT 
        i.id, 
        i.title_en, 
        i.title_fr, 
        i.status, 
        i.created_at,
        c.name_en as category_name_en,
        c.name_fr as category_name_fr,
        l.latitude,
        l.longitude,
        (SELECT image_url FROM item_images WHERE item_id = i.id AND is_primary = 1 LIMIT 1) as image_url
      FROM items i
      JOIN categories c ON i.category_id = c.id
      JOIN locations l ON i.location_id = l.id
      WHERE 1=1
    `;
    
    const queryParams = [];
    
    // Add filters
    if (category && category !== 'All') {
      query += ` AND c.name_en = ?`;
      queryParams.push(category);
    }
    
    if (status) {
      query += ` AND i.status = ?`;
      queryParams.push(status);
    }
    
    // Add distance filter if coordinates are provided
    if (latitude && longitude && distance) {
      // Haversine formula to calculate distance in kilometers
      query += `
        AND (
          6371 * acos(
            cos(radians(?)) * 
            cos(radians(l.latitude)) * 
            cos(radians(l.longitude) - radians(?)) + 
            sin(radians(?)) * 
            sin(radians(l.latitude))
          )
        ) <= ?
      `;
      queryParams.push(latitude, longitude, latitude, distance);
    }
    
    // Add sorting
    if (sortBy === 'newest') {
      query += ` ORDER BY i.created_at DESC`;
    } else if (sortBy === 'oldest') {
      query += ` ORDER BY i.created_at ASC`;
    } else if (sortBy === 'distance' && latitude && longitude) {
      query += `
        ORDER BY (
          6371 * acos(
            cos(radians(?)) * 
            cos(radians(l.latitude)) * 
            cos(radians(l.longitude) - radians(?)) + 
            sin(radians(?)) * 
            sin(radians(l.latitude))
          )
        ) ASC
      `;
      queryParams.push(latitude, longitude, latitude);
    }
    
    // Add pagination
    query += ` LIMIT ? OFFSET ?`;
    queryParams.push(limit, offset);
    
    // Execute the query
    let stmt = env.DB.prepare(query);
    
    // Bind all parameters
    for (let i = 0; i < queryParams.length; i++) {
      stmt = stmt.bind(queryParams[i]);
    }
    
    const items = await stmt.all();
    
    // Count total items for pagination
    let countQuery = `
      SELECT COUNT(*) as total
      FROM items i
      JOIN categories c ON i.category_id = c.id
      JOIN locations l ON i.location_id = l.id
      WHERE 1=1
    `;
    
    // Add the same filters to the count query
    if (category && category !== 'All') {
      countQuery += ` AND c.name_en = ?`;
    }
    
    if (status) {
      countQuery += ` AND i.status = ?`;
    }
    
    if (latitude && longitude && distance) {
      countQuery += `
        AND (
          6371 * acos(
            cos(radians(?)) * 
            cos(radians(l.latitude)) * 
            cos(radians(l.longitude) - radians(?)) + 
            sin(radians(?)) * 
            sin(radians(l.latitude))
          )
        ) <= ?
      `;
    }
    
    // Execute the count query
    let countStmt = env.DB.prepare(countQuery);
    
    // Bind parameters for count query (excluding limit and offset)
    for (let i = 0; i < queryParams.length - 2; i++) {
      countStmt = countStmt.bind(queryParams[i]);
    }
    
    const countResult = await countStmt.first();
    const total = countResult ? (countResult.total as number) : 0;
    
    // Return the items with pagination metadata
    return NextResponse.json({
      items: items.results,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit)
      }
    });
    
  } catch (error) {
    console.error('Error fetching items:', error);
    return NextResponse.json(
      { error: 'Failed to fetch items' },
      { status: 500 }
    );
  }
}
