"use client";

import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';

type AdBannerProps = {
  size: 'leaderboard' | 'medium-rectangle' | 'skyscraper' | 'mobile';
  className?: string;
  slot?: string;
};

const AdBanner: React.FC<AdBannerProps> = ({
  size,
  className = '',
  slot = '1234567890',
}) => {
  const { t } = useLanguage();
  const [isLoaded, setIsLoaded] = React.useState(false);
  const [isError, setIsError] = React.useState(false);
  
  // Define ad dimensions based on size
  const dimensions = {
    'leaderboard': { width: 728, height: 90 },
    'medium-rectangle': { width: 300, height: 250 },
    'skyscraper': { width: 160, height: 600 },
    'mobile': { width: 320, height: 100 },
  };
  
  // Simulate ad loading
  React.useEffect(() => {
    const timer = setTimeout(() => {
      // 90% chance of successful loading
      const success = Math.random() > 0.1;
      setIsLoaded(success);
      setIsError(!success);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);
  
  // In a real implementation, this would use the Google AdSense script
  // For this demo, we'll create a placeholder
  return (
    <div 
      className={`ad-container relative overflow-hidden ${className}`}
      style={{ 
        width: dimensions[size].width, 
        height: dimensions[size].height,
        maxWidth: '100%',
      }}
    >
      {!isLoaded && !isError && (
        <div className="absolute inset-0 bg-gray-100 animate-pulse flex items-center justify-center">
          <span className="text-gray-400 text-sm">{t('ads.loading')}</span>
        </div>
      )}
      
      {isError && (
        <div className="absolute inset-0 bg-gray-100 flex items-center justify-center">
          <span className="text-gray-400 text-sm">{t('ads.error')}</span>
        </div>
      )}
      
      {isLoaded && (
        <div 
          className="absolute inset-0 bg-gray-100 flex items-center justify-center border border-gray-200"
          style={{ backgroundColor: '#f0f0f0' }}
        >
          <div className="text-center p-2">
            <p className="text-gray-500 font-medium">{t('ads.sponsored')}</p>
            <p className="text-gray-400 text-xs">
              {size === 'leaderboard' && 'Leaderboard Ad (728×90)'}
              {size === 'medium-rectangle' && 'Medium Rectangle Ad (300×250)'}
              {size === 'skyscraper' && 'Skyscraper Ad (160×600)'}
              {size === 'mobile' && 'Mobile Banner Ad (320×100)'}
            </p>
            <p className="text-xs text-gray-400 mt-2">Ad Slot: {slot}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdBanner;
