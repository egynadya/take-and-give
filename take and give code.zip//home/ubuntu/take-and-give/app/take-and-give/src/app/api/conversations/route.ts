import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import { v4 as uuidv4 } from 'uuid';

interface Env {
  DB: D1Database;
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    
    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      );
    }
    
    // Get the database binding from the environment
    const env = request.cf as unknown as Env;
    
    // Get all conversations for the user
    const conversations = await env.DB.prepare(`
      SELECT 
        c.id,
        c.item_id,
        c.initiator_id,
        c.recipient_id,
        c.status,
        c.last_message_at,
        c.created_at,
        i.title_en,
        i.title_fr,
        i.status as item_status,
        u1.first_name as initiator_first_name,
        u1.last_name as initiator_last_name,
        u1.profile_image_url as initiator_profile_image,
        u2.first_name as recipient_first_name,
        u2.last_name as recipient_last_name,
        u2.profile_image_url as recipient_profile_image,
        (
          SELECT content FROM messages 
          WHERE conversation_id = c.id 
          ORDER BY created_at DESC LIMIT 1
        ) as last_message,
        (
          SELECT COUNT(*) FROM messages 
          WHERE conversation_id = c.id AND sender_id != ? AND is_read = 0
        ) as unread_count
      FROM conversations c
      JOIN items i ON c.item_id = i.id
      JOIN users u1 ON c.initiator_id = u1.id
      JOIN users u2 ON c.recipient_id = u2.id
      WHERE c.initiator_id = ? OR c.recipient_id = ?
      ORDER BY c.last_message_at DESC
    `)
    .bind(userId, userId, userId)
    .all();
    
    return NextResponse.json({
      conversations: conversations.results
    });
    
  } catch (error) {
    console.error('Error fetching conversations:', error);
    return NextResponse.json(
      { error: 'Failed to fetch conversations' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Validate required fields
    const requiredFields = ['itemId', 'initiatorId', 'recipientId'];
    for (const field of requiredFields) {
      if (!body[field]) {
        return NextResponse.json(
          { error: `Missing required field: ${field}` },
          { status: 400 }
        );
      }
    }
    
    // Get the database binding from the environment
    const env = request.cf as unknown as Env;
    
    // Check if a conversation already exists between these users for this item
    const existingConversation = await env.DB.prepare(`
      SELECT id FROM conversations 
      WHERE item_id = ? AND 
            ((initiator_id = ? AND recipient_id = ?) OR 
             (initiator_id = ? AND recipient_id = ?))
    `)
    .bind(
      body.itemId, 
      body.initiatorId, body.recipientId,
      body.recipientId, body.initiatorId
    )
    .first();
    
    if (existingConversation) {
      return NextResponse.json({
        success: true,
        conversationId: existingConversation.id,
        isNew: false
      });
    }
    
    // Generate a unique ID for the conversation
    const conversationId = `conv_${uuidv4()}`;
    
    // Create a new conversation
    await env.DB.prepare(`
      INSERT INTO conversations (
        id,
        item_id,
        initiator_id,
        recipient_id,
        status,
        last_message_at,
        created_at
      ) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `)
    .bind(
      conversationId,
      body.itemId,
      body.initiatorId,
      body.recipientId,
      'active'
    )
    .run();
    
    // If initial message is provided, add it
    if (body.initialMessage) {
      const messageId = `msg_${uuidv4()}`;
      
      await env.DB.prepare(`
        INSERT INTO messages (
          id,
          conversation_id,
          sender_id,
          content,
          is_read,
          created_at
        ) VALUES (?, ?, ?, ?, 0, CURRENT_TIMESTAMP)
      `)
      .bind(
        messageId,
        conversationId,
        body.initiatorId,
        body.initialMessage
      )
      .run();
    }
    
    return NextResponse.json({
      success: true,
      conversationId,
      isNew: true
    }, { status: 201 });
    
  } catch (error) {
    console.error('Error creating conversation:', error);
    return NextResponse.json(
      { error: 'Failed to create conversation' },
      { status: 500 }
    );
  }
}
