"use client";

import React from 'react';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import ItemCard from '../components/ui/ItemCard';
import Button from '../components/ui/Button';

const mockItems = [
  {
    id: '1',
    title: 'Wooden Dining Table',
    category: 'Furniture',
    distance: '2.5 km away',
    status: 'available',
  },
  {
    id: '2',
    title: 'Children\'s Bicycle',
    category: 'Kids',
    distance: '1.2 km away',
    status: 'available',
  },
  {
    id: '3',
    title: 'Winter Jacket (Size L)',
    category: 'Clothes & Fashion',
    distance: '3.7 km away',
    status: 'available',
  },
  {
    id: '4',
    title: 'Fiction Book Collection',
    category: 'Books',
    distance: '0.8 km away',
    status: 'reserved',
  },
  {
    id: '5',
    title: 'Coffee Table',
    category: 'Furniture',
    distance: '5.3 km away',
    status: 'available',
  },
  {
    id: '6',
    title: 'Baby Stroller',
    category: 'Kids',
    distance: '2.1 km away',
    status: 'available',
  },
  {
    id: '7',
    title: 'Desk Lamp',
    category: 'Miscellaneous',
    distance: '4.6 km away',
    status: 'available',
  },
  {
    id: '8',
    title: 'Summer Dress (Size M)',
    category: 'Clothes & Fashion',
    distance: '1.9 km away',
    status: 'available',
  },
  {
    id: '9',
    title: 'Cookbooks',
    category: 'Books',
    distance: '3.2 km away',
    status: 'available',
  },
];

const BrowsePage = () => {
  const [activeCategory, setActiveCategory] = React.useState('All');
  const [sortBy, setSortBy] = React.useState('distance');
  const [viewMode, setViewMode] = React.useState('grid');
  
  const categories = ['All', 'Furniture', 'Kids', 'Clothes & Fashion', 'Books', 'Miscellaneous'];
  
  const filteredItems = activeCategory === 'All' 
    ? mockItems 
    : mockItems.filter(item => item.category === activeCategory);
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Browse Items</h1>
        
        {/* Filters and Sort */}
        <div className="flex flex-col md:flex-row gap-6 mb-8">
          <div className="md:w-1/4 bg-white p-4 rounded-lg shadow-sm">
            <h2 className="text-lg font-medium mb-4">Filters</h2>
            
            <div className="mb-6">
              <h3 className="font-medium mb-2">Categories</h3>
              <div className="space-y-2">
                {categories.map(category => (
                  <div key={category} className="flex items-center">
                    <input
                      type="radio"
                      id={`category-${category}`}
                      name="category"
                      checked={activeCategory === category}
                      onChange={() => setActiveCategory(category)}
                      className="mr-2"
                    />
                    <label htmlFor={`category-${category}`}>{category}</label>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="mb-6">
              <h3 className="font-medium mb-2">Distance</h3>
              <input
                type="range"
                min="1"
                max="50"
                defaultValue="10"
                className="w-full"
              />
              <div className="flex justify-between text-sm text-gray-500">
                <span>1 km</span>
                <span>50 km</span>
              </div>
            </div>
            
            <div className="mb-6">
              <h3 className="font-medium mb-2">Location</h3>
              <input
                type="text"
                placeholder="Enter your location"
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
              />
            </div>
            
            <Button variant="primary" fullWidth>Apply Filters</Button>
          </div>
          
          <div className="md:w-3/4">
            <div className="flex justify-between items-center mb-4">
              <div className="text-gray-600">
                {filteredItems.length} items found
              </div>
              <div className="flex items-center space-x-4">
                <div>
                  <label htmlFor="sort-by" className="mr-2 text-sm">Sort by:</label>
                  <select
                    id="sort-by"
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="border border-gray-300 rounded-md px-2 py-1"
                  >
                    <option value="distance">Distance</option>
                    <option value="newest">Newest</option>
                    <option value="oldest">Oldest</option>
                  </select>
                </div>
                <div className="flex border border-gray-300 rounded-md">
                  <button
                    className={`px-3 py-1 ${viewMode === 'grid' ? 'bg-gray-100' : ''}`}
                    onClick={() => setViewMode('grid')}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
                    </svg>
                  </button>
                  <button
                    className={`px-3 py-1 ${viewMode === 'list' ? 'bg-gray-100' : ''}`}
                    onClick={() => setViewMode('list')}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                  </button>
                </div>
                <button className="border border-gray-300 rounded-md px-3 py-1 flex items-center space-x-1">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                  </svg>
                  <span>Map</span>
                </button>
              </div>
            </div>
            
            {/* Items Grid/List */}
            <div className={`${viewMode === 'grid' ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6' : 'space-y-4'}`}>
              {filteredItems.map(item => (
                viewMode === 'grid' ? (
                  <ItemCard
                    key={item.id}
                    title={item.title}
                    category={item.category}
                    distance={item.distance}
                    status={item.status as 'available' | 'reserved' | 'completed'}
                    onClick={() => console.log(`Clicked on item ${item.id}`)}
                  />
                ) : (
                  <div key={item.id} className="flex border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition">
                    <div className="w-32 h-32 bg-gray-200 flex-shrink-0">
                      <div className="h-full w-full flex items-center justify-center text-gray-500">
                        No Image
                      </div>
                    </div>
                    <div className="p-4 flex-grow">
                      <h3 className="font-medium mb-1">{item.title}</h3>
                      <p className="text-sm text-gray-500 mb-2">{item.category}</p>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">{item.distance}</span>
                        <span className={`text-xs px-2 py-1 rounded ${
                          item.status === 'available' ? 'bg-green-100 text-green-800' :
                          item.status === 'reserved' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-gray-100 text-gray-800'
                        }`}>
                          {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                        </span>
                      </div>
                    </div>
                  </div>
                )
              ))}
            </div>
            
            {/* Load More Button */}
            <div className="mt-8 text-center">
              <Button variant="outline">Load More</Button>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default BrowsePage;
