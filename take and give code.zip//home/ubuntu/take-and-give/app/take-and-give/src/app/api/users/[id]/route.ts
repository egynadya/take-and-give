import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import { v4 as uuidv4 } from 'uuid';

interface Env {
  DB: D1Database;
}

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params;
    
    // Get the database binding from the environment
    const env = request.cf as unknown as Env;
    
    // Get user profile
    const user = await env.DB.prepare(`
      SELECT 
        id, 
        email, 
        first_name, 
        last_name, 
        profile_image_url, 
        phone_number, 
        bio, 
        preferred_language,
        created_at,
        last_login_at
      FROM users
      WHERE id = ?
    `)
    .bind(id)
    .first();
    
    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }
    
    // Get user stats
    const stats = await env.DB.prepare(`
      SELECT
        (SELECT COUNT(*) FROM items WHERE donor_id = ? AND status = 'available') as available_items,
        (SELECT COUNT(*) FROM items WHERE donor_id = ? AND status = 'completed') as given_items,
        (SELECT COUNT(*) FROM items WHERE recipient_id = ?) as received_items
    `)
    .bind(id, id, id)
    .first();
    
    // Get user locations
    const locations = await env.DB.prepare(`
      SELECT id, address_line1, address_line2, city, state_province, postal_code, country, latitude, longitude, is_default
      FROM locations
      WHERE user_id = ?
      ORDER BY is_default DESC, created_at ASC
    `)
    .bind(id)
    .all();
    
    return NextResponse.json({
      user,
      stats,
      locations: locations.results
    });
    
  } catch (error) {
    console.error('Error fetching user profile:', error);
    return NextResponse.json(
      { error: 'Failed to fetch user profile' },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params;
    const body = await request.json();
    
    // Get the database binding from the environment
    const env = request.cf as unknown as Env;
    
    // Check if user exists
    const user = await env.DB.prepare(
      `SELECT id FROM users WHERE id = ?`
    )
    .bind(id)
    .first();
    
    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }
    
    // Build update query
    const updateFields = [];
    const updateValues = [];
    
    if (body.first_name) {
      updateFields.push('first_name = ?');
      updateValues.push(body.first_name);
    }
    
    if (body.last_name) {
      updateFields.push('last_name = ?');
      updateValues.push(body.last_name);
    }
    
    if (body.profile_image_url !== undefined) {
      updateFields.push('profile_image_url = ?');
      updateValues.push(body.profile_image_url);
    }
    
    if (body.phone_number !== undefined) {
      updateFields.push('phone_number = ?');
      updateValues.push(body.phone_number);
    }
    
    if (body.bio !== undefined) {
      updateFields.push('bio = ?');
      updateValues.push(body.bio);
    }
    
    if (body.preferred_language) {
      updateFields.push('preferred_language = ?');
      updateValues.push(body.preferred_language);
    }
    
    if (body.notification_preferences) {
      updateFields.push('notification_preferences = ?');
      updateValues.push(JSON.stringify(body.notification_preferences));
    }
    
    if (updateFields.length === 0) {
      return NextResponse.json(
        { error: 'No fields to update' },
        { status: 400 }
      );
    }
    
    updateFields.push('updated_at = CURRENT_TIMESTAMP');
    
    // Update user
    const query = `
      UPDATE users 
      SET ${updateFields.join(', ')} 
      WHERE id = ?
    `;
    
    let stmt = env.DB.prepare(query);
    
    // Bind all parameters
    for (let i = 0; i < updateValues.length; i++) {
      stmt = stmt.bind(updateValues[i]);
    }
    
    // Bind the user ID as the last parameter
    stmt = stmt.bind(id);
    
    await stmt.run();
    
    // Get updated user
    const updatedUser = await env.DB.prepare(`
      SELECT 
        id, 
        email, 
        first_name, 
        last_name, 
        profile_image_url, 
        phone_number, 
        bio, 
        preferred_language,
        notification_preferences,
        created_at,
        updated_at
      FROM users
      WHERE id = ?
    `)
    .bind(id)
    .first();
    
    return NextResponse.json({
      success: true,
      user: updatedUser
    });
    
  } catch (error) {
    console.error('Error updating user profile:', error);
    return NextResponse.json(
      { error: 'Failed to update user profile' },
      { status: 500 }
    );
  }
}
