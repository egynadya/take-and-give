import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import { v4 as uuidv4 } from 'uuid';

interface Env {
  DB: D1Database;
}

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params;
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    
    // Get the database binding from the environment
    const env = request.cf as unknown as Env;
    
    // Build query
    let query = `
      SELECT 
        i.id, 
        i.title_en, 
        i.title_fr, 
        i.status, 
        i.created_at,
        c.name_en as category_name_en,
        c.name_fr as category_name_fr,
        l.latitude,
        l.longitude,
        (SELECT image_url FROM item_images WHERE item_id = i.id AND is_primary = 1 LIMIT 1) as image_url
      FROM items i
      JOIN categories c ON i.category_id = c.id
      JOIN locations l ON i.location_id = l.id
      WHERE (i.donor_id = ? OR i.recipient_id = ?)
    `;
    
    const queryParams = [id, id];
    
    if (status) {
      query += ` AND i.status = ?`;
      queryParams.push(status);
    }
    
    query += ` ORDER BY i.created_at DESC`;
    
    // Execute the query
    let stmt = env.DB.prepare(query);
    
    // Bind all parameters
    for (let i = 0; i < queryParams.length; i++) {
      stmt = stmt.bind(queryParams[i]);
    }
    
    const items = await stmt.all();
    
    return NextResponse.json({
      items: items.results
    });
    
  } catch (error) {
    console.error('Error fetching user items:', error);
    return NextResponse.json(
      { error: 'Failed to fetch user items' },
      { status: 500 }
    );
  }
}
