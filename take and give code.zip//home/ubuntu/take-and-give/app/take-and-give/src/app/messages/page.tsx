"use client";

import React from 'react';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import MessageBubble from '../components/ui/MessageBubble';

const MessagesPage = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Messages</h1>
        
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-3">
            {/* Conversations List */}
            <div className="border-r border-gray-200">
              <div className="p-4 border-b border-gray-200">
                <Input 
                  placeholder="Search messages..." 
                  className="mb-0"
                />
              </div>
              
              <div className="overflow-y-auto" style={{ maxHeight: '600px' }}>
                {[1, 2, 3, 4, 5].map((index) => (
                  <div 
                    key={index} 
                    className={`p-4 border-b border-gray-200 hover:bg-gray-50 cursor-pointer ${index === 1 ? 'bg-gray-50' : ''}`}
                  >
                    <div className="flex items-start">
                      <div className="w-10 h-10 bg-gray-200 rounded-full mr-3 flex-shrink-0"></div>
                      <div className="flex-grow min-w-0">
                        <div className="flex justify-between items-center mb-1">
                          <h3 className="font-medium truncate">User {index}</h3>
                          <span className="text-xs text-gray-500 whitespace-nowrap ml-2">
                            {index === 1 ? '2 min ago' : 
                             index === 2 ? 'Yesterday' : 
                             `${index} days ago`}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <p className="text-sm text-gray-600 truncate">
                            Re: {index === 1 ? 'Wooden Dining Table' : 
                                 index === 2 ? 'Children\'s Bicycle' : 
                                 index === 3 ? 'Winter Jacket' :
                                 index === 4 ? 'Fiction Book Collection' :
                                 'Coffee Table'}
                          </p>
                          {index === 1 && (
                            <span className="w-2 h-2 bg-[rgb(var(--primary-color))] rounded-full ml-2"></span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Conversation */}
            <div className="md:col-span-2 flex flex-col" style={{ height: '600px' }}>
              {/* Conversation Header */}
              <div className="p-4 border-b border-gray-200 flex justify-between items-center">
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-gray-200 rounded-full mr-3"></div>
                  <div>
                    <h3 className="font-medium">User 1</h3>
                    <p className="text-sm text-gray-600">Re: Wooden Dining Table</p>
                  </div>
                </div>
                <div>
                  <Button variant="outline" size="sm">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                    </svg>
                    View Item
                  </Button>
                </div>
              </div>
              
              {/* Messages */}
              <div className="flex-grow p-4 overflow-y-auto">
                <div className="space-y-4">
                  <MessageBubble 
                    content="Hello, I'm interested in your wooden dining table. Is it still available?"
                    timestamp="Monday, 10:15 AM"
                    isOwn={false}
                  />
                  
                  <MessageBubble 
                    content="Yes, it's still available! When would you like to pick it up?"
                    timestamp="Monday, 10:30 AM"
                    isOwn={true}
                    status="read"
                  />
                  
                  <MessageBubble 
                    content="Great! Would tomorrow at 5pm work for you?"
                    timestamp="Monday, 10:45 AM"
                    isOwn={false}
                  />
                  
                  <MessageBubble 
                    content="Tomorrow at 5pm works perfectly. Here's my address: 123 Rue Saint-Michel, Paris. There's a code to enter the building: 4567. I'm on the 3rd floor, apartment 302."
                    timestamp="Monday, 11:00 AM"
                    isOwn={true}
                    status="read"
                  />
                  
                  <MessageBubble 
                    content="Perfect! I'll be there at 5pm tomorrow. Do you need help carrying it down?"
                    timestamp="Monday, 11:15 AM"
                    isOwn={false}
                  />
                  
                  <MessageBubble 
                    content="No need, it's not too heavy. We can manage it together. See you tomorrow!"
                    timestamp="Monday, 11:30 AM"
                    isOwn={true}
                    status="delivered"
                  />
                  
                  <div className="text-center text-sm text-gray-500 my-4">Today</div>
                  
                  <MessageBubble 
                    content="Just confirming that we're still on for 5pm today?"
                    timestamp="2 minutes ago"
                    isOwn={false}
                  />
                </div>
              </div>
              
              {/* Message Input */}
              <div className="p-4 border-t border-gray-200">
                <div className="flex">
                  <input 
                    type="text" 
                    placeholder="Type a message..." 
                    className="flex-grow px-4 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-[rgb(var(--primary-color))] focus:border-transparent"
                  />
                  <button className="bg-[rgb(var(--primary-color))] text-white px-4 py-2 rounded-r-md hover:bg-opacity-90 transition">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                    </svg>
                  </button>
                </div>
              </div>
              
              {/* Item Status */}
              <div className="p-4 border-t border-gray-200 flex justify-between">
                <Button variant="outline" size="sm">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Mark as Reserved
                </Button>
                
                <Button variant="outline" size="sm">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Mark as Completed
                </Button>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default MessagesPage;
