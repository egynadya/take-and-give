"use client";

import React from 'react';
import { useLocation, TransportationOption } from '../../contexts/LocationContext';
import { useLanguage } from '../../contexts/LanguageContext';

type LocationPickerProps = {
  onLocationSelect?: (latitude: number, longitude: number, address: string) => void;
  className?: string;
};

const LocationPicker: React.FC<LocationPickerProps> = ({
  onLocationSelect,
  className = '',
}) => {
  const { userLocation, isLocating, locationError, requestLocation } = useLocation();
  const { t } = useLanguage();
  const [address, setAddress] = React.useState('');
  const [isSearching, setIsSearching] = React.useState(false);
  
  // Request location when component mounts
  React.useEffect(() => {
    if (!userLocation) {
      requestLocation();
    }
  }, []);
  
  // Reverse geocode to get address from coordinates
  React.useEffect(() => {
    if (userLocation) {
      setIsSearching(true);
      
      // In a real implementation, this would call a geocoding API
      // For this demo, we'll simulate a delay and return a fake address
      setTimeout(() => {
        const fakeAddress = '123 Main Street, Paris, France';
        setAddress(fakeAddress);
        setIsSearching(false);
        
        if (onLocationSelect) {
          onLocationSelect(userLocation.latitude, userLocation.longitude, fakeAddress);
        }
      }, 1000);
    }
  }, [userLocation]);
  
  return (
    <div className={`p-4 border border-gray-200 rounded-lg ${className}`}>
      <h3 className="font-medium mb-3">{t('location.your_location')}</h3>
      
      {locationError && (
        <div className="mb-3 p-3 bg-red-50 text-red-700 rounded-md">
          <p>{locationError}</p>
          <button 
            onClick={requestLocation}
            className="mt-2 text-sm font-medium text-red-700 hover:text-red-800"
          >
            {t('location.try_again')}
          </button>
        </div>
      )}
      
      {isLocating && (
        <div className="flex items-center space-x-2 mb-3">
          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-[rgb(var(--primary-color))]"></div>
          <p>{t('location.detecting')}</p>
        </div>
      )}
      
      {isSearching && (
        <div className="flex items-center space-x-2 mb-3">
          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-[rgb(var(--primary-color))]"></div>
          <p>{t('location.getting_address')}</p>
        </div>
      )}
      
      {userLocation && !isSearching && (
        <div className="mb-3">
          <p className="text-gray-700 mb-1">{address}</p>
          <p className="text-sm text-gray-500">
            {t('location.coordinates')}: {userLocation.latitude.toFixed(6)}, {userLocation.longitude.toFixed(6)}
          </p>
        </div>
      )}
      
      <div className="flex flex-col space-y-2">
        <button
          onClick={requestLocation}
          className="px-4 py-2 bg-[rgb(var(--primary-color))] text-white rounded-md hover:bg-opacity-90 transition"
          disabled={isLocating}
        >
          {userLocation ? t('location.update_location') : t('location.detect_location')}
        </button>
        
        <button
          className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50 transition"
        >
          {t('location.enter_manually')}
        </button>
      </div>
    </div>
  );
};

export default LocationPicker;
