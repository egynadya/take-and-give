"use client";

import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// Define the context type
interface LocationContextType {
  userLocation: GeolocationCoordinates | null;
  isLocating: boolean;
  locationError: string | null;
  requestLocation: () => void;
  calculateDistance: (lat1: number, lon1: number, lat2: number, lon2: number) => number;
  getTransportationOptions: (distance: number) => TransportationOption[];
}

export type TransportationOption = {
  mode: 'walking' | 'cycling' | 'driving' | 'transit';
  icon: string;
  estimatedTime: string;
  distance: string;
};

// Create the context with default values
const LocationContext = createContext<LocationContextType>({
  userLocation: null,
  isLocating: false,
  locationError: null,
  requestLocation: () => {},
  calculateDistance: () => 0,
  getTransportationOptions: () => [],
});

// Provider component
interface LocationProviderProps {
  children: ReactNode;
}

export const LocationProvider = ({ children }: LocationProviderProps) => {
  const [userLocation, setUserLocation] = useState<GeolocationCoordinates | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);

  // Request user's location
  const requestLocation = () => {
    if (!navigator.geolocation) {
      setLocationError('Geolocation is not supported by your browser');
      return;
    }

    setIsLocating(true);
    setLocationError(null);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setUserLocation(position.coords);
        setIsLocating(false);
      },
      (error) => {
        setLocationError(getGeolocationErrorMessage(error.code));
        setIsLocating(false);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  // Get error message based on error code
  const getGeolocationErrorMessage = (errorCode: number): string => {
    switch (errorCode) {
      case 1:
        return 'Permission denied. Please allow location access to use this feature.';
      case 2:
        return 'Location information is unavailable. Please try again.';
      case 3:
        return 'The request to get user location timed out. Please try again.';
      default:
        return 'An unknown error occurred while trying to get your location.';
    }
  };

  // Calculate distance between two points using Haversine formula (in kilometers)
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371; // Radius of the earth in km
    const dLat = deg2rad(lat2 - lat1);
    const dLon = deg2rad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c; // Distance in km
    return distance;
  };

  // Convert degrees to radians
  const deg2rad = (deg: number): number => {
    return deg * (Math.PI / 180);
  };

  // Get transportation options based on distance
  const getTransportationOptions = (distance: number): TransportationOption[] => {
    const options: TransportationOption[] = [];

    // Walking (up to 5 km)
    if (distance <= 5) {
      const walkingTime = Math.round(distance / 5 * 60); // Assuming 5 km/h walking speed
      options.push({
        mode: 'walking',
        icon: '🚶',
        estimatedTime: `${walkingTime} min`,
        distance: `${distance.toFixed(1)} km`,
      });
    }

    // Cycling (up to 15 km)
    if (distance <= 15) {
      const cyclingTime = Math.round(distance / 15 * 60); // Assuming 15 km/h cycling speed
      options.push({
        mode: 'cycling',
        icon: '🚲',
        estimatedTime: `${cyclingTime} min`,
        distance: `${distance.toFixed(1)} km`,
      });
    }

    // Transit (any distance)
    const transitTime = Math.round(distance / 30 * 60); // Assuming 30 km/h transit speed
    options.push({
      mode: 'transit',
      icon: '🚌',
      estimatedTime: `${transitTime} min`,
      distance: `${distance.toFixed(1)} km`,
    });

    // Driving (any distance)
    const drivingTime = Math.round(distance / 50 * 60); // Assuming 50 km/h driving speed
    options.push({
      mode: 'driving',
      icon: '🚗',
      estimatedTime: `${drivingTime} min`,
      distance: `${distance.toFixed(1)} km`,
    });

    return options;
  };

  return (
    <LocationContext.Provider
      value={{
        userLocation,
        isLocating,
        locationError,
        requestLocation,
        calculateDistance,
        getTransportationOptions,
      }}
    >
      {children}
    </LocationContext.Provider>
  );
};

// Custom hook to use the location context
export const useLocation = () => useContext(LocationContext);
