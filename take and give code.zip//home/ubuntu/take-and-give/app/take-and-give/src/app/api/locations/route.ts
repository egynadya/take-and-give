import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import { v4 as uuidv4 } from 'uuid';

interface Env {
  DB: D1Database;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Validate required fields
    const requiredFields = ['userId', 'address_line1', 'city', 'state_province', 'postal_code', 'country', 'latitude', 'longitude'];
    for (const field of requiredFields) {
      if (!body[field]) {
        return NextResponse.json(
          { error: `Missing required field: ${field}` },
          { status: 400 }
        );
      }
    }
    
    // Get the database binding from the environment
    const env = request.cf as unknown as Env;
    
    // Generate a unique ID for the location
    const locationId = `loc_${uuidv4()}`;
    
    // If this is set as default, unset any existing default locations
    if (body.is_default) {
      await env.DB.prepare(`
        UPDATE locations 
        SET is_default = 0 
        WHERE user_id = ?
      `)
      .bind(body.userId)
      .run();
    }
    
    // Insert the location
    await env.DB.prepare(`
      INSERT INTO locations (
        id,
        user_id,
        address_line1,
        address_line2,
        city,
        state_province,
        postal_code,
        country,
        latitude,
        longitude,
        is_default,
        created_at,
        updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    `)
    .bind(
      locationId,
      body.userId,
      body.address_line1,
      body.address_line2 || null,
      body.city,
      body.state_province,
      body.postal_code,
      body.country,
      body.latitude,
      body.longitude,
      body.is_default ? 1 : 0
    )
    .run();
    
    // Return the created location ID
    return NextResponse.json({
      success: true,
      locationId
    }, { status: 201 });
    
  } catch (error) {
    console.error('Error creating location:', error);
    return NextResponse.json(
      { error: 'Failed to create location' },
      { status: 500 }
    );
  }
}
