"use client";

import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { useChat, Message } from '../../contexts/ChatContext';

type ChatInterfaceProps = {
  conversationId: string;
  currentUserId: string;
  itemId?: string;
  className?: string;
};

const ChatInterface: React.FC<ChatInterfaceProps> = ({
  conversationId,
  currentUserId,
  itemId,
  className = '',
}) => {
  const { t } = useLanguage();
  const { currentConversation, isLoading, error, fetchMessages, sendMessage, selectConversation } = useChat();
  const [messageText, setMessageText] = useState('');
  const messagesEndRef = React.useRef<HTMLDivElement>(null);

  // Fetch messages when component mounts or conversation changes
  useEffect(() => {
    if (conversationId) {
      fetchMessages(conversationId);
      selectConversation(conversationId);
    }
  }, [conversationId]);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentConversation?.messages]);

  // Handle sending a message
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!messageText.trim() || !conversationId) return;
    
    sendMessage(conversationId, currentUserId, messageText);
    setMessageText('');
  };

  // Determine if a message is from the current user
  const isOwnMessage = (message: Message) => {
    return message.senderId === currentUserId;
  };

  // Format timestamp
  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  if (!currentConversation) {
    return (
      <div className={`flex flex-col h-full ${className}`}>
        <div className="flex-grow flex items-center justify-center">
          <p className="text-gray-500">{t('messages.select_conversation')}</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`flex flex-col h-full border border-gray-200 rounded-lg overflow-hidden ${className}`}>
      {/* Chat header */}
      <div className="p-4 border-b border-gray-200 bg-white">
        <div className="flex items-center">
          <div className="w-10 h-10 bg-gray-200 rounded-full mr-3"></div>
          <div>
            <h3 className="font-medium">
              {currentConversation.initiatorId === currentUserId 
                ? 'Recipient Name' // In a real app, get the actual name
                : 'Initiator Name'}
            </h3>
            {itemId && (
              <button className="text-sm text-[rgb(var(--secondary-color))] hover:underline">
                {t('messages.view_item')}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Messages area */}
      <div className="flex-grow p-4 overflow-y-auto bg-gray-50">
        {isLoading && currentConversation.messages.length === 0 ? (
          <div className="flex justify-center py-4">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-[rgb(var(--primary-color))]"></div>
          </div>
        ) : (
          <>
            {currentConversation.messages.length === 0 ? (
              <p className="text-center text-gray-500 py-4">{t('messages.no_messages')}</p>
            ) : (
              <div className="space-y-3">
                {currentConversation.messages.map((message) => (
                  <div 
                    key={message.id} 
                    className={`flex ${isOwnMessage(message) ? 'justify-end' : 'justify-start'}`}
                  >
                    <div 
                      className={`max-w-[75%] rounded-lg px-4 py-2 ${
                        isOwnMessage(message) 
                          ? 'bg-[rgb(var(--primary-color))] text-white rounded-br-none' 
                          : 'bg-white border border-gray-200 rounded-bl-none'
                      }`}
                    >
                      <p>{message.content}</p>
                      <p className={`text-xs mt-1 ${isOwnMessage(message) ? 'text-white text-opacity-75' : 'text-gray-500'}`}>
                        {formatTime(message.timestamp)}
                        {isOwnMessage(message) && (
                          <span className="ml-1">
                            {message.isRead ? '✓✓' : '✓'}
                          </span>
                        )}
                      </p>
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
            )}
          </>
        )}
      </div>

      {/* Message input */}
      <div className="p-3 border-t border-gray-200 bg-white">
        <form onSubmit={handleSendMessage} className="flex items-center">
          <input
            type="text"
            value={messageText}
            onChange={(e) => setMessageText(e.target.value)}
            placeholder={t('messages.type_message')}
            className="flex-grow px-4 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-[rgb(var(--primary-color))] focus:border-transparent"
          />
          <button
            type="submit"
            disabled={!messageText.trim()}
            className="px-4 py-2 bg-[rgb(var(--primary-color))] text-white rounded-r-md hover:bg-opacity-90 transition disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
            </svg>
          </button>
        </form>
      </div>
    </div>
  );
};

export default ChatInterface;
