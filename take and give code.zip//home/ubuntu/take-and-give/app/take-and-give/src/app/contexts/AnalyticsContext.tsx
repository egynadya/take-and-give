"use client";

import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// Define the context type
interface AnalyticsContextType {
  trackPageView: (pageName: string) => void;
  trackEvent: (category: string, action: string, label?: string, value?: number) => void;
  trackConversion: (conversionId: string, value?: number) => void;
  isAnalyticsEnabled: boolean;
  setAnalyticsEnabled: (enabled: boolean) => void;
}

// Create the context with default values
const AnalyticsContext = createContext<AnalyticsContextType>({
  trackPageView: () => {},
  trackEvent: () => {},
  trackConversion: () => {},
  isAnalyticsEnabled: true,
  setAnalyticsEnabled: () => {},
});

// Provider component
interface AnalyticsProviderProps {
  children: ReactNode;
}

export const AnalyticsProvider = ({ children }: AnalyticsProviderProps) => {
  // Check if analytics is enabled in localStorage
  const getInitialAnalyticsState = (): boolean => {
    if (typeof window !== 'undefined') {
      const savedState = localStorage.getItem('analytics_enabled');
      return savedState === null ? true : savedState === 'true';
    }
    return true;
  };

  const [isAnalyticsEnabled, setIsAnalyticsEnabledState] = useState<boolean>(true);
  
  // Initialize analytics state after component mounts (to avoid SSR issues)
  useEffect(() => {
    setIsAnalyticsEnabledState(getInitialAnalyticsState());
  }, []);
  
  // Set analytics state and save to localStorage
  const setAnalyticsEnabled = (enabled: boolean) => {
    setIsAnalyticsEnabledState(enabled);
    if (typeof window !== 'undefined') {
      localStorage.setItem('analytics_enabled', enabled.toString());
    }
  };

  // Track page view
  const trackPageView = (pageName: string) => {
    if (!isAnalyticsEnabled) return;
    
    // In a real implementation, this would call Google Analytics
    console.log(`[Analytics] Page View: ${pageName}`);
    
    // Example Google Analytics code (would be used in production)
    if (typeof window !== 'undefined' && 'gtag' in window) {
      // @ts-ignore
      window.gtag('config', 'GA-MEASUREMENT-ID', {
        page_path: window.location.pathname,
        page_title: pageName,
      });
    }
  };

  // Track event
  const trackEvent = (category: string, action: string, label?: string, value?: number) => {
    if (!isAnalyticsEnabled) return;
    
    // In a real implementation, this would call Google Analytics
    console.log(`[Analytics] Event: ${category} / ${action} / ${label || 'N/A'} / ${value || 'N/A'}`);
    
    // Example Google Analytics code (would be used in production)
    if (typeof window !== 'undefined' && 'gtag' in window) {
      // @ts-ignore
      window.gtag('event', action, {
        event_category: category,
        event_label: label,
        value: value,
      });
    }
  };

  // Track conversion
  const trackConversion = (conversionId: string, value?: number) => {
    if (!isAnalyticsEnabled) return;
    
    // In a real implementation, this would call Google Ads conversion tracking
    console.log(`[Analytics] Conversion: ${conversionId} / ${value || 'N/A'}`);
    
    // Example Google Ads conversion code (would be used in production)
    if (typeof window !== 'undefined' && 'gtag' in window) {
      // @ts-ignore
      window.gtag('event', 'conversion', {
        send_to: `AW-CONVERSION-ID/${conversionId}`,
        value: value,
        currency: 'USD',
      });
    }
  };

  return (
    <AnalyticsContext.Provider
      value={{
        trackPageView,
        trackEvent,
        trackConversion,
        isAnalyticsEnabled,
        setAnalyticsEnabled,
      }}
    >
      {children}
    </AnalyticsContext.Provider>
  );
};

// Custom hook to use the analytics context
export const useAnalytics = () => useContext(AnalyticsContext);

// Analytics script component to add to _app.js or layout.tsx
export const AnalyticsScript: React.FC<{ measurementId: string }> = ({ measurementId }) => {
  return (
    <>
      <script
        async
        src={`https://www.googletagmanager.com/gtag/js?id=${measurementId}`}
      />
      <script
        dangerouslySetInnerHTML={{
          __html: `
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', '${measurementId}');
          `,
        }}
      />
    </>
  );
};
