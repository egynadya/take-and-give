"use client";

import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { useAnalytics } from '../../contexts/AnalyticsContext';
import AdBanner from './AdBanner';

type AdPlacementProps = {
  location: 'header' | 'sidebar' | 'footer' | 'content' | 'mobile';
  className?: string;
};

const AdPlacement: React.FC<AdPlacementProps> = ({
  location,
  className = '',
}) => {
  const { t } = useLanguage();
  const { trackEvent } = useAnalytics();
  
  // Define ad sizes and slots based on location
  const getAdConfig = () => {
    switch (location) {
      case 'header':
        return {
          size: 'leaderboard' as const,
          slot: 'header_12345',
          className: 'mx-auto my-4'
        };
      case 'sidebar':
        return {
          size: 'medium-rectangle' as const,
          slot: 'sidebar_67890',
          className: 'mx-auto my-4'
        };
      case 'footer':
        return {
          size: 'leaderboard' as const,
          slot: 'footer_54321',
          className: 'mx-auto my-4'
        };
      case 'content':
        return {
          size: 'medium-rectangle' as const,
          slot: 'content_09876',
          className: 'float-right ml-4 mb-4 md:ml-6 md:mb-6'
        };
      case 'mobile':
        return {
          size: 'mobile' as const,
          slot: 'mobile_13579',
          className: 'mx-auto my-4'
        };
      default:
        return {
          size: 'medium-rectangle' as const,
          slot: 'default_24680',
          className: 'mx-auto my-4'
        };
    }
  };
  
  const config = getAdConfig();
  
  // Track ad impression
  React.useEffect(() => {
    trackEvent('ad', 'impression', `${location}_${config.size}`);
  }, []);
  
  // Determine if ad should be shown based on viewport
  const [shouldShow, setShouldShow] = React.useState(true);
  
  React.useEffect(() => {
    const checkViewport = () => {
      // Don't show desktop ads on mobile
      if (location === 'header' || location === 'sidebar' || location === 'footer') {
        setShouldShow(window.innerWidth >= 768);
      }
      
      // Don't show mobile ads on desktop
      if (location === 'mobile') {
        setShouldShow(window.innerWidth < 768);
      }
    };
    
    checkViewport();
    window.addEventListener('resize', checkViewport);
    
    return () => {
      window.removeEventListener('resize', checkViewport);
    };
  }, [location]);
  
  if (!shouldShow) {
    return null;
  }
  
  return (
    <div className={`ad-placement ad-${location} ${className}`}>
      <AdBanner 
        size={config.size} 
        slot={config.slot} 
        className={config.className} 
      />
      <div className="text-xs text-gray-400 text-center mt-1">
        {t('ads.ad_disclosure')}
      </div>
    </div>
  );
};

export default AdPlacement;
