import Link from 'next/link';
import Image from 'next/image';

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="bg-white shadow-sm py-4">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold text-[rgb(var(--primary-color))]">Take & Give</h1>
          </div>
          <div className="flex items-center space-x-4">
            <div className="relative">
              <input
                type="text"
                placeholder="Search for items..."
                className="w-64 px-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-[rgb(var(--primary-color))]"
              />
              <button className="absolute right-3 top-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </button>
            </div>
            <div className="flex space-x-2">
              <Link href="/signup" className="px-4 py-2 bg-[rgb(var(--primary-color))] text-white rounded-md hover:bg-opacity-90 transition">
                Sign Up
              </Link>
              <Link href="/login" className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50 transition">
                Log In
              </Link>
            </div>
            <button className="p-2 rounded-md hover:bg-gray-100">
              <span>🇬🇧</span>
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-b from-white to-gray-100 py-16">
        <div className="container mx-auto px-4 flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-8 md:mb-0">
            <h2 className="text-4xl font-bold mb-4">Give and receive items for free, no limitations</h2>
            <p className="text-lg text-gray-600 mb-6">
              Take & Give connects people who want to give away items they no longer need with those who could use them.
              No restrictions, no virtual credits, just a community of sharing.
            </p>
            <div className="flex space-x-4">
              <Link href="/browse" className="px-6 py-3 bg-[rgb(var(--primary-color))] text-white rounded-md hover:bg-opacity-90 transition font-medium">
                Browse Items
              </Link>
              <Link href="/signup" className="px-6 py-3 bg-[rgb(var(--secondary-color))] text-white rounded-md hover:bg-opacity-90 transition font-medium">
                Get Started
              </Link>
            </div>
          </div>
          <div className="md:w-1/2 flex justify-center">
            <div className="relative w-full max-w-md h-80 bg-gray-200 rounded-lg overflow-hidden">
              {/* Placeholder for hero image */}
              <div className="absolute inset-0 flex items-center justify-center text-gray-500">
                Hero Image Placeholder
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Items Section */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold mb-6">Featured Items</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((item) => (
              <div key={item} className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition">
                <div className="h-48 bg-gray-200 relative">
                  {/* Placeholder for item image */}
                  <div className="absolute inset-0 flex items-center justify-center text-gray-500">
                    Item Image
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-medium mb-1">Item Title {item}</h3>
                  <p className="text-sm text-gray-500 mb-2">Category</p>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">2.5 km away</span>
                    <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">Available</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-8 text-center">
            <Link href="/browse" className="px-6 py-2 border border-[rgb(var(--primary-color))] text-[rgb(var(--primary-color))] rounded-md hover:bg-[rgb(var(--primary-color))] hover:text-white transition">
              View All Items
            </Link>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold mb-6">Categories</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
            {['Furniture', 'Kids', 'Clothes & Fashion', 'Books', 'Miscellaneous'].map((category, index) => (
              <Link 
                href={`/browse?category=${category.toLowerCase()}`} 
                key={index}
                className="bg-white rounded-lg p-4 text-center shadow-sm hover:shadow-md transition flex flex-col items-center"
              >
                <div className="w-16 h-16 bg-[rgba(var(--primary-color),0.1)] rounded-full flex items-center justify-center mb-3">
                  <span className="text-2xl">
                    {index === 0 && '🪑'}
                    {index === 1 && '🧸'}
                    {index === 2 && '👕'}
                    {index === 3 && '📚'}
                    {index === 4 && '📦'}
                  </span>
                </div>
                <span className="font-medium">{category}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold mb-8 text-center">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-[rgba(var(--primary-color),0.1)] rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">📸</span>
              </div>
              <h3 className="text-xl font-medium mb-2">1. List Your Items</h3>
              <p className="text-gray-600">Take a photo, add a description, and share your item with the community.</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-[rgba(var(--primary-color),0.1)] rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">💬</span>
              </div>
              <h3 className="text-xl font-medium mb-2">2. Connect</h3>
              <p className="text-gray-600">Chat with interested people and arrange a pickup time and location.</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-[rgba(var(--primary-color),0.1)] rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🤝</span>
              </div>
              <h3 className="text-xl font-medium mb-2">3. Exchange</h3>
              <p className="text-gray-600">Meet up and give your item a new home. No fees, no limits, no hassle.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Success Stories Section */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold mb-8 text-center">Success Stories</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-gray-200 rounded-full mr-4"></div>
                <div>
                  <h3 className="font-medium">Sarah L.</h3>
                  <p className="text-sm text-gray-500">Paris, France</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "I was moving apartments and had furniture I couldn't take with me. 
                Instead of throwing it away, I found someone who needed it through Take & Give. 
                The process was so simple and it feels great knowing my items are being used!"
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-gray-200 rounded-full mr-4"></div>
                <div>
                  <h3 className="font-medium">Thomas M.</h3>
                  <p className="text-sm text-gray-500">Lyon, France</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "As a student on a tight budget, Take & Give has been a lifesaver. 
                I've furnished most of my apartment with items from generous people in my community. 
                No restrictions or complicated credit systems - just simple sharing!"
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8 mt-auto">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-bold mb-4">Take & Give</h3>
              <p className="text-gray-300 text-sm">
                A platform for giving away and receiving free items, with no limitations.
              </p>
            </div>
            <div>
              <h4 className="font-medium mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li><Link href="/about" className="hover:text-white">About</Link></li>
                <li><Link href="/browse" className="hover:text-white">Browse Items</Link></li>
                <li><Link href="/faq" className="hover:text-white">FAQ</Link></li>
                <li><Link href="/contact" className="hover:text-white">Contact Us</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li><Link href="/terms" className="hover:text-white">Terms of Service</Link></li>
                <li><Link href="/privacy" className="hover:text-white">Privacy Policy</Link></li>
                <li><Link href="/cookies" className="hover:text-white">Cookie Policy</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-4">Support Us</h4>
              <p className="text-gray-300 text-sm mb-4">
                Help us keep Take & Give free for everyone.
              </p>
              <Link href="/donate" className="px-4 py-2 bg-[rgb(var(--primary-color))] text-white rounded-md hover:bg-opacity-90 transition text-sm inline-block">
                Donate
              </Link>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-6 text-center text-sm text-gray-400">
            <p>© 2025 Take & Give. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
