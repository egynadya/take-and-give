import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';

interface Env {
  DB: D1Database;
}

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params;
    const { searchParams } = new URL(request.url);
    
    // Get the database binding from the environment
    const env = request.cf as unknown as Env;
    
    // Query the database for the item with the given ID
    const item = await env.DB.prepare(
      `SELECT 
        i.id, 
        i.title_en, 
        i.title_fr, 
        i.description_en, 
        i.description_fr, 
        i.category_id, 
        i.donor_id, 
        i.recipient_id, 
        i.location_id, 
        i.condition, 
        i.status, 
        i.is_featured, 
        i.view_count, 
        i.created_at, 
        i.updated_at, 
        i.completed_at,
        c.name_en as category_name_en,
        c.name_fr as category_name_fr,
        u.first_name as donor_first_name,
        u.last_name as donor_last_name,
        u.profile_image_url as donor_profile_image,
        l.address_line1,
        l.city,
        l.state_province,
        l.postal_code,
        l.latitude,
        l.longitude
      FROM items i
      JOIN categories c ON i.category_id = c.id
      JOIN users u ON i.donor_id = u.id
      JOIN locations l ON i.location_id = l.id
      WHERE i.id = ?`
    )
    .bind(id)
    .first();
    
    if (!item) {
      return NextResponse.json(
        { error: 'Item not found' },
        { status: 404 }
      );
    }
    
    // Increment view count
    await env.DB.prepare(
      `UPDATE items SET view_count = view_count + 1 WHERE id = ?`
    )
    .bind(id)
    .run();
    
    // Get item images
    const images = await env.DB.prepare(
      `SELECT id, image_url, display_order, is_primary
       FROM item_images
       WHERE item_id = ?
       ORDER BY display_order ASC`
    )
    .bind(id)
    .all();
    
    // Get similar items (same category, different item)
    const similarItems = await env.DB.prepare(
      `SELECT 
        i.id, 
        i.title_en, 
        i.status, 
        c.name_en as category_name,
        l.latitude,
        l.longitude,
        (SELECT image_url FROM item_images WHERE item_id = i.id AND is_primary = 1 LIMIT 1) as image_url
       FROM items i
       JOIN categories c ON i.category_id = c.id
       JOIN locations l ON i.location_id = l.id
       WHERE i.category_id = ? AND i.id != ? AND i.status = 'available'
       LIMIT 4`
    )
    .bind(item.category_id, id)
    .all();
    
    // Return the item with its images and similar items
    return NextResponse.json({
      item,
      images: images.results,
      similarItems: similarItems.results
    });
    
  } catch (error) {
    console.error('Error fetching item:', error);
    return NextResponse.json(
      { error: 'Failed to fetch item' },
      { status: 500 }
    );
  }
}
