import React from 'react';
import { LanguageProvider, useLanguage } from '../../contexts/LanguageContext';

// Language switcher component
export const LanguageSwitcher: React.FC = () => {
  const { language, setLanguage, t } = useLanguage();

  return (
    <div className="relative">
      <button 
        className="p-2 rounded-md hover:bg-gray-100 flex items-center"
        onClick={() => setLanguage(language === 'en' ? 'fr' : 'en')}
      >
        <span className="mr-1">{language === 'en' ? '🇬🇧' : '🇫🇷'}</span>
        <span className="text-sm">{language === 'en' ? 'EN' : 'FR'}</span>
      </button>
    </div>
  );
};

// Wrapper component to provide language context to the entire app
export const LanguageWrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <LanguageProvider>
      {children}
    </LanguageProvider>
  );
};

export default LanguageSwitcher;
