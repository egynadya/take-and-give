import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { useLocation } from '../../contexts/LocationContext';

type TransportationOptionsProps = {
  latitude: number;
  longitude: number;
  className?: string;
};

const TransportationOptions: React.FC<TransportationOptionsProps> = ({
  latitude,
  longitude,
  className = '',
}) => {
  const { t } = useLanguage();
  const { userLocation, calculateDistance, getTransportationOptions } = useLocation();
  
  // If no user location, show a message to enable location
  if (!userLocation) {
    return (
      <div className={`p-4 border border-gray-200 rounded-lg ${className}`}>
        <h3 className="font-medium mb-2">{t('item.transportation')}</h3>
        <p className="text-gray-600 text-sm">
          {t('location.enable_to_see_options')}
        </p>
      </div>
    );
  }
  
  // Calculate distance between user and item
  const distance = calculateDistance(
    userLocation.latitude,
    userLocation.longitude,
    latitude,
    longitude
  );
  
  // Get transportation options based on distance
  const options = getTransportationOptions(distance);
  
  return (
    <div className={`p-4 border border-gray-200 rounded-lg ${className}`}>
      <h3 className="font-medium mb-3">{t('item.transportation')}</h3>
      <p className="text-sm text-gray-600 mb-3">
        {t('location.distance_away', { distance: distance.toFixed(1) })}
      </p>
      
      <div className="space-y-3">
        {options.map((option) => (
          <div key={option.mode} className="flex items-center p-2 border border-gray-200 rounded-md">
            <div className="text-2xl mr-3">{option.icon}</div>
            <div>
              <p className="font-medium">{t(`transportation.${option.mode}`)}</p>
              <p className="text-sm text-gray-600">
                {option.estimatedTime} • {option.distance}
              </p>
            </div>
          </div>
        ))}
      </div>
      
      <button className="mt-3 w-full px-4 py-2 bg-[rgb(var(--secondary-color))] text-white rounded-md hover:bg-opacity-90 transition text-sm">
        {t('location.view_on_map')}
      </button>
    </div>
  );
};

export default TransportationOptions;
