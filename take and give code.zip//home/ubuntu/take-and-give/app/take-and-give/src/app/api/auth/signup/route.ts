import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import { v4 as uuidv4 } from 'uuid';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

interface Env {
  DB: D1Database;
  JWT_SECRET: string;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Validate required fields
    const requiredFields = ['email', 'password', 'first_name', 'last_name'];
    for (const field of requiredFields) {
      if (!body[field]) {
        return NextResponse.json(
          { error: `Missing required field: ${field}` },
          { status: 400 }
        );
      }
    }
    
    // Get the database binding from the environment
    const env = request.cf as unknown as Env;
    
    // Check if user already exists
    const existingUser = await env.DB.prepare(
      `SELECT id FROM users WHERE email = ?`
    )
    .bind(body.email.toLowerCase())
    .first();
    
    if (existingUser) {
      return NextResponse.json(
        { error: 'User with this email already exists' },
        { status: 409 }
      );
    }
    
    // Hash the password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(body.password, salt);
    
    // Generate a unique ID for the user
    const userId = `user_${uuidv4()}`;
    
    // Insert the user into the database
    await env.DB.prepare(`
      INSERT INTO users (
        id,
        email,
        password_hash,
        first_name,
        last_name,
        profile_image_url,
        phone_number,
        bio,
        preferred_language
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)
    .bind(
      userId,
      body.email.toLowerCase(),
      hashedPassword,
      body.first_name,
      body.last_name,
      body.profile_image_url || null,
      body.phone_number || null,
      body.bio || null,
      body.preferred_language || 'en'
    )
    .run();
    
    // Create JWT token
    const token = jwt.sign(
      { userId, email: body.email },
      env.JWT_SECRET || 'default_secret_key_for_development',
      { expiresIn: '7d' }
    );
    
    // Return user data and token
    return NextResponse.json({
      success: true,
      user: {
        id: userId,
        email: body.email,
        first_name: body.first_name,
        last_name: body.last_name,
        preferred_language: body.preferred_language || 'en'
      },
      token
    }, { status: 201 });
    
  } catch (error) {
    console.error('Error creating user:', error);
    return NextResponse.json(
      { error: 'Failed to create user' },
      { status: 500 }
    );
  }
}
