"use client";

import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import Button from '../ui/Button';

type DonationBoxProps = {
  className?: string;
};

const DonationBox: React.FC<DonationBoxProps> = ({
  className = '',
}) => {
  const { t } = useLanguage();
  const [amount, setAmount] = useState<number | ''>('');
  const [customAmount, setCustomAmount] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isDonationComplete, setIsDonationComplete] = useState(false);
  
  const predefinedAmounts = [5, 10, 25, 50];
  
  const handleAmountSelect = (value: number) => {
    setAmount(value);
    setCustomAmount(false);
  };
  
  const handleCustomAmountClick = () => {
    setAmount('');
    setCustomAmount(true);
  };
  
  const handleCustomAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (value === '' || /^\d+(\.\d{0,2})?$/.test(value)) {
      setAmount(value === '' ? '' : parseFloat(value));
    }
  };
  
  const handleDonate = () => {
    if (amount === '' || amount <= 0) return;
    
    setIsProcessing(true);
    
    // Simulate donation processing
    setTimeout(() => {
      setIsProcessing(false);
      setIsDonationComplete(true);
      
      // Reset after showing success message
      setTimeout(() => {
        setIsDonationComplete(false);
        setAmount('');
        setCustomAmount(false);
      }, 5000);
    }, 2000);
  };
  
  return (
    <div className={`bg-white border border-gray-200 rounded-lg p-5 ${className}`}>
      <h3 className="text-lg font-medium mb-3">{t('donation.title')}</h3>
      <p className="text-gray-600 mb-4">{t('donation.description')}</p>
      
      {isDonationComplete ? (
        <div className="bg-green-50 text-green-700 p-4 rounded-md mb-4">
          <div className="flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
            <p className="font-medium">{t('donation.thank_you')}</p>
          </div>
          <p className="mt-1 text-sm">{t('donation.confirmation')}</p>
        </div>
      ) : (
        <>
          <div className="mb-4">
            <p className="text-sm font-medium mb-2">{t('donation.select_amount')}</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {predefinedAmounts.map((value) => (
                <button
                  key={value}
                  onClick={() => handleAmountSelect(value)}
                  className={`py-2 rounded-md transition ${
                    amount === value && !customAmount
                      ? 'bg-[rgb(var(--primary-color))] text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  ${value}
                </button>
              ))}
            </div>
          </div>
          
          <div className="mb-4">
            <button
              onClick={handleCustomAmountClick}
              className={`text-sm text-[rgb(var(--secondary-color))] hover:underline ${
                customAmount ? 'font-medium' : ''
              }`}
            >
              {t('donation.custom_amount')}
            </button>
            
            {customAmount && (
              <div className="mt-2">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <span className="text-gray-500">$</span>
                  </div>
                  <input
                    type="text"
                    value={amount}
                    onChange={handleCustomAmountChange}
                    className="w-full pl-7 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[rgb(var(--primary-color))] focus:border-transparent"
                    placeholder="0.00"
                    autoFocus
                  />
                </div>
              </div>
            )}
          </div>
          
          <Button
            variant="primary"
            onClick={handleDonate}
            disabled={amount === '' || amount <= 0 || isProcessing}
            fullWidth
          >
            {isProcessing ? (
              <div className="flex items-center justify-center">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                {t('donation.processing')}
              </div>
            ) : (
              t('donation.donate_button')
            )}
          </Button>
        </>
      )}
      
      <div className="mt-4 text-xs text-gray-500">
        <p>{t('donation.secure_payment')}</p>
        <div className="flex items-center mt-2 space-x-2">
          <span>🔒</span>
          <span>{t('donation.payment_methods')}: Visa, Mastercard, PayPal</span>
        </div>
      </div>
    </div>
  );
};

export default DonationBox;
