import React from 'react';

type CategoryCardProps = {
  name: string;
  icon: string;
  onClick?: () => void;
  className?: string;
};

const CategoryCard: React.FC<CategoryCardProps> = ({
  name,
  icon,
  onClick,
  className = '',
}) => {
  return (
    <div 
      className={`bg-white rounded-lg p-4 text-center shadow-sm hover:shadow-md transition flex flex-col items-center cursor-pointer ${className}`}
      onClick={onClick}
    >
      <div className="w-16 h-16 bg-[rgba(var(--primary-color),0.1)] rounded-full flex items-center justify-center mb-3">
        <span className="text-2xl">{icon}</span>
      </div>
      <span className="font-medium">{name}</span>
    </div>
  );
};

export default CategoryCard;
