import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import { v4 as uuidv4 } from 'uuid';

interface Env {
  DB: D1Database;
}

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params;
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const before = searchParams.get('before');
    
    // Get the database binding from the environment
    const env = request.cf as unknown as Env;
    
    // Verify conversation exists
    const conversation = await env.DB.prepare(
      `SELECT * FROM conversations WHERE id = ?`
    )
    .bind(id)
    .first();
    
    if (!conversation) {
      return NextResponse.json(
        { error: 'Conversation not found' },
        { status: 404 }
      );
    }
    
    // Build query for messages
    let query = `
      SELECT 
        m.id,
        m.sender_id,
        m.content,
        m.is_read,
        m.created_at,
        u.first_name,
        u.last_name,
        u.profile_image_url
      FROM messages m
      JOIN users u ON m.sender_id = u.id
      WHERE m.conversation_id = ?
    `;
    
    const queryParams = [id];
    
    if (before) {
      query += ` AND m.created_at < ?`;
      queryParams.push(before);
    }
    
    query += ` ORDER BY m.created_at DESC LIMIT ?`;
    queryParams.push(limit);
    
    // Execute the query
    let stmt = env.DB.prepare(query);
    
    // Bind all parameters
    for (let i = 0; i < queryParams.length; i++) {
      stmt = stmt.bind(queryParams[i]);
    }
    
    const messages = await stmt.all();
    
    // Mark messages as read if userId is provided
    const userId = searchParams.get('userId');
    if (userId) {
      await env.DB.prepare(`
        UPDATE messages 
        SET is_read = 1 
        WHERE conversation_id = ? AND sender_id != ? AND is_read = 0
      `)
      .bind(id, userId)
      .run();
    }
    
    return NextResponse.json({
      conversation,
      messages: messages.results.reverse() // Return in chronological order
    });
    
  } catch (error) {
    console.error('Error fetching messages:', error);
    return NextResponse.json(
      { error: 'Failed to fetch messages' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params;
    const body = await request.json();
    
    // Validate required fields
    if (!body.senderId || !body.content) {
      return NextResponse.json(
        { error: 'Sender ID and content are required' },
        { status: 400 }
      );
    }
    
    // Get the database binding from the environment
    const env = request.cf as unknown as Env;
    
    // Verify conversation exists
    const conversation = await env.DB.prepare(
      `SELECT * FROM conversations WHERE id = ?`
    )
    .bind(id)
    .first();
    
    if (!conversation) {
      return NextResponse.json(
        { error: 'Conversation not found' },
        { status: 404 }
      );
    }
    
    // Verify sender is part of the conversation
    if (conversation.initiator_id !== body.senderId && conversation.recipient_id !== body.senderId) {
      return NextResponse.json(
        { error: 'Sender is not part of this conversation' },
        { status: 403 }
      );
    }
    
    // Generate a unique ID for the message
    const messageId = `msg_${uuidv4()}`;
    
    // Insert the message
    await env.DB.prepare(`
      INSERT INTO messages (
        id,
        conversation_id,
        sender_id,
        content,
        is_read,
        created_at
      ) VALUES (?, ?, ?, ?, 0, CURRENT_TIMESTAMP)
    `)
    .bind(
      messageId,
      id,
      body.senderId,
      body.content
    )
    .run();
    
    // Update the conversation's last_message_at timestamp
    await env.DB.prepare(`
      UPDATE conversations 
      SET last_message_at = CURRENT_TIMESTAMP 
      WHERE id = ?
    `)
    .bind(id)
    .run();
    
    // Get the created message with sender info
    const message = await env.DB.prepare(`
      SELECT 
        m.id,
        m.sender_id,
        m.content,
        m.is_read,
        m.created_at,
        u.first_name,
        u.last_name,
        u.profile_image_url
      FROM messages m
      JOIN users u ON m.sender_id = u.id
      WHERE m.id = ?
    `)
    .bind(messageId)
    .first();
    
    return NextResponse.json({
      success: true,
      message
    }, { status: 201 });
    
  } catch (error) {
    console.error('Error sending message:', error);
    return NextResponse.json(
      { error: 'Failed to send message' },
      { status: 500 }
    );
  }
}
