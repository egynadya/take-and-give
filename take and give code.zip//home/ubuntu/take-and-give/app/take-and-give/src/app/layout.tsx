import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { LanguageWrapper } from "./components/ui/LanguageSwitcher";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Take & Give - Free Item Exchange Platform",
  description: "Give away and receive free items with no limitations",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <LanguageWrapper>
          <main className="min-h-screen">{children}</main>
        </LanguageWrapper>
      </body>
    </html>
  );
}
