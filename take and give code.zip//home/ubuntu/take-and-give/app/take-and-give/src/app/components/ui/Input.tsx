import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';

type InputProps = {
  type?: 'text' | 'email' | 'password' | 'number' | 'tel' | 'url' | 'date';
  label?: string;
  labelKey?: string;
  placeholder?: string;
  placeholderKey?: string;
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  error?: string;
  required?: boolean;
  disabled?: boolean;
  className?: string;
  id?: string;
  name?: string;
};

const Input: React.FC<InputProps> = ({
  type = 'text',
  label,
  labelKey,
  placeholder,
  placeholderKey,
  value,
  onChange,
  error,
  required = false,
  disabled = false,
  className = '',
  id,
  name,
}) => {
  const { t } = useLanguage();
  const inputId = id || `input-${Math.random().toString(36).substr(2, 9)}`;
  
  const displayLabel = labelKey ? t(labelKey) : label;
  const displayPlaceholder = placeholderKey ? t(placeholderKey) : placeholder;
  
  return (
    <div className={`mb-4 ${className}`}>
      {displayLabel && (
        <label htmlFor={inputId} className="block text-sm font-medium text-gray-700 mb-1">
          {displayLabel}
          {required && <span className="text-red-500 ml-1">*</span>}
        </label>
      )}
      <input
        type={type}
        id={inputId}
        name={name}
        className={`w-full px-3 py-2 border ${
          error ? 'border-red-500' : 'border-gray-300'
        } rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-[rgb(var(--primary-color))] focus:border-transparent ${
          disabled ? 'bg-gray-100 cursor-not-allowed' : ''
        }`}
        placeholder={displayPlaceholder}
        value={value}
        onChange={onChange}
        required={required}
        disabled={disabled}
      />
      {error && <p className="mt-1 text-sm text-red-500">{error}</p>}
    </div>
  );
};

export default Input;
