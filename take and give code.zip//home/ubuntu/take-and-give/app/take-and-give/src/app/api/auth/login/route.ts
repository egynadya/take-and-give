import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

interface Env {
  DB: D1Database;
  JWT_SECRET: string;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Validate required fields
    if (!body.email || !body.password) {
      return NextResponse.json(
        { error: 'Email and password are required' },
        { status: 400 }
      );
    }
    
    // Get the database binding from the environment
    const env = request.cf as unknown as Env;
    
    // Find the user by email
    const user = await env.DB.prepare(
      `SELECT id, email, password_hash, first_name, last_name, preferred_language FROM users WHERE email = ?`
    )
    .bind(body.email.toLowerCase())
    .first();
    
    if (!user) {
      return NextResponse.json(
        { error: 'Invalid credentials' },
        { status: 401 }
      );
    }
    
    // Verify password
    const isPasswordValid = await bcrypt.compare(body.password, user.password_hash);
    
    if (!isPasswordValid) {
      return NextResponse.json(
        { error: 'Invalid credentials' },
        { status: 401 }
      );
    }
    
    // Update last login timestamp
    await env.DB.prepare(
      `UPDATE users SET last_login_at = CURRENT_TIMESTAMP WHERE id = ?`
    )
    .bind(user.id)
    .run();
    
    // Create JWT token
    const token = jwt.sign(
      { userId: user.id, email: user.email },
      env.JWT_SECRET || 'default_secret_key_for_development',
      { expiresIn: '7d' }
    );
    
    // Return user data and token
    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        first_name: user.first_name,
        last_name: user.last_name,
        preferred_language: user.preferred_language
      },
      token
    });
    
  } catch (error) {
    console.error('Error logging in:', error);
    return NextResponse.json(
      { error: 'Failed to log in' },
      { status: 500 }
    );
  }
}
