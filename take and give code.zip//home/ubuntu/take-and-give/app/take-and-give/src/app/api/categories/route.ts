import { NextRequest, NextResponse } from 'next/server';
import { D1Database } from '@cloudflare/workers-types';
import { v4 as uuidv4 } from 'uuid';

interface Env {
  DB: D1Database;
}

export async function GET(request: NextRequest) {
  try {
    // Get the database binding from the environment
    const env = request.cf as unknown as Env;
    
    // Get all categories
    const categories = await env.DB.prepare(`
      SELECT 
        id, 
        name_en, 
        name_fr, 
        description_en, 
        description_fr, 
        icon_url, 
        parent_id, 
        display_order
      FROM categories
      WHERE is_active = 1
      ORDER BY display_order ASC
    `)
    .all();
    
    return NextResponse.json({
      categories: categories.results
    });
    
  } catch (error) {
    console.error('Error fetching categories:', error);
    return NextResponse.json(
      { error: 'Failed to fetch categories' },
      { status: 500 }
    );
  }
}
