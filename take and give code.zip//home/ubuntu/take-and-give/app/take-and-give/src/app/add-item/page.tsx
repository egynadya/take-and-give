"use client";

import React from 'react';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';

const AddItemPage = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Add New Item</h1>
        
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <h2 className="text-xl font-medium mb-4">Item Information</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Input 
                label="Title (English)" 
                placeholder="Enter item title" 
                required 
              />
            </div>
            <div>
              <Input 
                label="Title (French)" 
                placeholder="Entrez le titre de l'article" 
              />
            </div>
          </div>
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Category <span className="text-red-500">*</span>
            </label>
            <select className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-[rgb(var(--primary-color))] focus:border-transparent">
              <option value="">Select a category</option>
              <option value="furniture">Furniture</option>
              <option value="kids">Kids</option>
              <option value="clothes">Clothes & Fashion</option>
              <option value="books">Books</option>
              <option value="misc">Miscellaneous</option>
            </select>
          </div>
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Condition <span className="text-red-500">*</span>
            </label>
            <select className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-[rgb(var(--primary-color))] focus:border-transparent">
              <option value="">Select condition</option>
              <option value="new">New</option>
              <option value="like_new">Like New</option>
              <option value="good">Good</option>
              <option value="fair">Fair</option>
            </select>
          </div>
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Description (English) <span className="text-red-500">*</span>
            </label>
            <textarea 
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-[rgb(var(--primary-color))] focus:border-transparent"
              rows={5}
              placeholder="Describe your item in detail (condition, size, color, etc.)"
            ></textarea>
          </div>
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Description (French)
            </label>
            <textarea 
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-[rgb(var(--primary-color))] focus:border-transparent"
              rows={5}
              placeholder="Décrivez votre article en détail (état, taille, couleur, etc.)"
            ></textarea>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <h2 className="text-xl font-medium mb-4">Photos</h2>
          <p className="text-gray-600 mb-4">Add up to 5 photos of your item. The first photo will be the main image.</p>
          
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            <p className="text-gray-600 mb-2">Drag and drop photos here</p>
            <p className="text-gray-500 text-sm mb-4">or</p>
            <Button variant="outline" size="sm">Browse Files</Button>
          </div>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {[1, 2, 3, 4, 5].map((index) => (
              <div key={index} className="relative border border-gray-200 rounded-lg overflow-hidden h-32 bg-gray-100 flex items-center justify-center">
                <div className="text-gray-400 text-sm">Photo {index}</div>
                {index === 1 && (
                  <div className="absolute top-2 left-2 bg-[rgb(var(--primary-color))] text-white text-xs px-2 py-1 rounded">
                    Main
                  </div>
                )}
                <button className="absolute top-2 right-2 bg-white rounded-full p-1 shadow-sm">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            ))}
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <h2 className="text-xl font-medium mb-4">Location</h2>
          
          <div className="mb-4">
            <div className="flex items-center mb-4">
              <input 
                type="checkbox" 
                id="use-default-location" 
                className="mr-2"
                defaultChecked
              />
              <label htmlFor="use-default-location">Use my default location</label>
            </div>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Or select another location
              </label>
              <select className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-[rgb(var(--primary-color))] focus:border-transparent">
                <option value="">Select a saved location</option>
                <option value="home">Home</option>
                <option value="work">Work</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Or enter a new location
              </label>
              <Input 
                placeholder="Address" 
                className="mb-2"
              />
              <div className="grid grid-cols-2 gap-4 mb-2">
                <Input 
                  placeholder="City" 
                />
                <Input 
                  placeholder="Postal Code" 
                />
              </div>
              <Button variant="outline" size="sm" className="mt-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                </svg>
                Show on Map
              </Button>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <h2 className="text-xl font-medium mb-4">Availability</h2>
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Available from
            </label>
            <Input 
              type="date"
              defaultValue={new Date().toISOString().split('T')[0]}
            />
          </div>
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Preferred pickup times
            </label>
            <div className="grid grid-cols-3 gap-4 mb-4">
              <div className="flex items-center">
                <input 
                  type="checkbox" 
                  id="morning" 
                  className="mr-2"
                />
                <label htmlFor="morning">Morning</label>
              </div>
              <div className="flex items-center">
                <input 
                  type="checkbox" 
                  id="afternoon" 
                  className="mr-2"
                />
                <label htmlFor="afternoon">Afternoon</label>
              </div>
              <div className="flex items-center">
                <input 
                  type="checkbox" 
                  id="evening" 
                  className="mr-2"
                />
                <label htmlFor="evening">Evening</label>
              </div>
            </div>
            
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Days of week
            </label>
            <div className="grid grid-cols-4 gap-4">
              {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map((day) => (
                <div key={day} className="flex items-center">
                  <input 
                    type="checkbox" 
                    id={day.toLowerCase()} 
                    className="mr-2"
                  />
                  <label htmlFor={day.toLowerCase()}>{day}</label>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        <div className="flex justify-end space-x-4">
          <Button variant="outline">Cancel</Button>
          <Button variant="outline">Preview</Button>
          <Button variant="primary">Publish</Button>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default AddItemPage;
